# InternConnect

A PHP and MySQL internship platform. Students keep one profile and apply with a
click; companies post internships and move applicants through a fixed set of
stages. Plain PHP, PDO, vanilla JavaScript and CSS, with no frameworks.

## Requirements

- PHP 8.2 or newer (tested design target: 8.2, 8.3, 8.4)
- PDO with the `pdo_mysql` driver
- A MySQL or MariaDB database
- Optional: `curl` (otherwise PHP streams are used), `fileinfo`, `mbstring`.
  None are required; the code detects each and falls back.

## Run locally

From the folder that contains `internship-portal`:

    php -S 0.0.0.0:8080 -t internship-portal

No `.htaccess` or rewrite rules are needed.

## Configuration

Settings are read, in this order, from real environment variables, a `.env`
placed one level **above** the web root, then `config/env.local.php`.

1. Copy `config/env.local.example.php` to `config/env.local.php` and fill it in
   (or use `.env.example` as a template for a `.env` outside the web root).
2. Never commit or share the filled-in file. The repository ships placeholders only.

| Name | Purpose |
| --- | --- |
| `DB_HOST`, `DB_PORT`, `DB_NAME`, `DB_USER`, `DB_PASS` | Database connection |
| `APP_URL` | Public site address, used for links in emails |
| `RESEND_API_KEY`, `RESEND_FROM_EMAIL`, `RESEND_FROM_NAME` | Password reset email |
| `STORAGE_PATH` | Optional private folder for sessions and resumes |

## Database

Run `database/internconnect.sql` against your database. It is idempotent. The
two newest tables (`password_resets`, `support_queries`) are also created
automatically on first use if missing.

## Password reset with Resend

1. Create a Resend account, add and verify a sending domain, and create an API key.
2. Set `RESEND_API_KEY`, `RESEND_FROM_EMAIL` (an address on the verified domain),
   `RESEND_FROM_NAME` and `APP_URL`.
3. Request a reset from `forgot-password.php`.

Tokens come from `random_bytes()`, only their SHA-256 hash is stored, they expire
after one hour, work once, and requesting a new one invalidates older ones. The
page gives the same answer whether or not the email is registered. Reset links
are built from `APP_URL`, never from the request's Host header. If `APP_URL` or
the Resend settings are missing, the failure is logged and the visitor still sees
the neutral message.

## Queries and support

`support.php` stores requests in `support_queries` (category, subject, message,
optional reference, status Open / In Progress / Resolved / Closed). Logged-in
users also see the status of their own recent requests. There is no admin screen;
statuses are changed in the database.

## Application workflow

Applied, Under Review, Shortlisted, Interview, then Selected or Rejected. The
status always comes from the `applications` table. The triangular tracker on the
home page and student dashboard renders that status; the home page also lists
recent real events from `activity.php`, which never exposes personal data.

## Folder structure

    internship-portal/
      index.php login.php register.php logout.php
      forgot-password.php reset-password.php support.php
      activity.php resume.php favicon.svg
      student/   dashboard, profile, internships, internship_details, apply, applications
      company/   dashboard, add_internship, internships, applicants
      includes/  auth (session bootstrap), helpers, mail, schema, tracker, header, footer
      config/    database.php, env.local.example.php
      css/ js/ database/

## Security notes

- One session bootstrap (`includes/auth.php`); HttpOnly, SameSite=Lax, Secure on
  HTTPS, strict mode, cookies only.
- Prepared statements everywhere; output escaped with `clean()`.
- CSRF token on every state-changing form; roles checked on every protected page;
  companies can only act on their own internships and applicants.
- Resumes are stored under random names in a private folder and served through
  `resume.php`, which checks who is asking. Uploads are checked for type, size and
  file signature.
- Sessions and resumes go to `internconnect-storage` beside the project when that
  folder can be created, otherwise `storage/` inside it. The built-in PHP server
  ignores `.htaccess`, so prefer the sibling folder or set `STORAGE_PATH`.
