<?php
/**
 * Public activity feed (JSON). Only aggregate, non-personal facts taken from
 * the database: newly posted open internships and the stage applications have
 * reached. No applicant names or emails are ever included.
 */
require_once __DIR__ . '/includes/auth.php';

header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store');

$pdo = getDBConnectionOrNull();
if ($pdo === null) {
    echo json_encode(['events' => [], 'latest_state' => 'idle', 'server_time' => time()]);
    exit;
}

require_once __DIR__ . '/includes/tracker_state.php';

$events = [];
$latestState = 'idle';

try {
    $internships = $pdo->query(
        "SELECT i.title, c.company_name, UNIX_TIMESTAMP(i.posted_at) AS happened_at
         FROM internships i JOIN companies c ON c.id = i.company_id
         WHERE i.status = 'Open'
         ORDER BY i.posted_at DESC LIMIT 6"
    )->fetchAll();

    foreach ($internships as $row) {
        $events[] = [
            'kind' => 'internship',
            'text' => 'New internship posted: ' . $row['title'] . ' at ' . $row['company_name'],
            'at'   => (int) $row['happened_at'],
        ];
    }

    $applications = $pdo->query(
        'SELECT status, UNIX_TIMESTAMP(updated_at) AS happened_at
         FROM applications ORDER BY updated_at DESC LIMIT 6'
    )->fetchAll();

    $phrases = [
        'Applied'      => 'A new application was submitted',
        'Under Review' => 'An application moved to Under Review',
        'Shortlisted'  => 'An application was shortlisted',
        'Interview'    => 'An application reached the Interview stage',
        'Selected'     => 'A candidate was selected',
        'Rejected'     => 'An application was closed',
    ];
    foreach ($applications as $index => $row) {
        if ($index === 0) {
            $latestState = tracker_state_from_status($row['status']);
        }
        $events[] = [
            'kind'  => 'application',
            'state' => tracker_state_from_status($row['status']),
            'text'  => $phrases[$row['status']] ?? 'An application was updated',
            'at'    => (int) $row['happened_at'],
        ];
    }
} catch (PDOException $e) {
    error_log('InternConnect: activity feed query failed (code ' . $e->getCode() . ').');
}

usort($events, static function (array $a, array $b): int {
    return $b['at'] <=> $a['at'];
});

echo json_encode([
    'events'       => array_slice($events, 0, 8),
    'latest_state' => $latestState,
    'server_time'  => time(),
], JSON_UNESCAPED_UNICODE);
