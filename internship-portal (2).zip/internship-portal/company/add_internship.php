<?php
require_once __DIR__ . '/../includes/auth.php';
require_role('company');

$pdo = getDBConnection();
$company = get_company_profile($pdo, current_user_id());
$errors = [];

$old = ['title' => '', 'description' => '', 'skills_required' => '', 'location' => '',
        'work_mode' => 'Remote', 'stipend' => '', 'duration' => '', 'deadline' => ''];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!csrf_verify($_POST['csrf_token'] ?? '')) {
        $errors[] = 'Your session expired. Please try again.';
    }
    if (!$company) {
        $errors[] = 'No company profile found for this account.';
    }

    foreach ($old as $key => $_) {
        $old[$key] = trim((string) ($_POST[$key] ?? ''));
    }

    if (safe_strlen($old['title']) < 3) $errors[] = 'Give the role a title.';
    if (safe_strlen($old['description']) < 20) $errors[] = 'Add a description of at least 20 characters.';
    if (!in_array($old['work_mode'], ['Remote', 'Onsite', 'Hybrid'])) $old['work_mode'] = 'Remote';
    if ($old['deadline'] !== '' && !preg_match('/^\d{4}-\d{2}-\d{2}$/', $old['deadline'])) {
        $errors[] = 'Enter a valid deadline date.';
    }

    if (!$errors) {
        $stmt = $pdo->prepare("
            INSERT INTO internships (company_id, title, description, skills_required, location, work_mode, stipend, duration, deadline)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
        ");
        $stmt->execute([
            $company['id'], $old['title'], $old['description'], $old['skills_required'],
            $old['location'], $old['work_mode'], $old['stipend'], $old['duration'],
            $old['deadline'] ?: null,
        ]);
        set_flash('success', 'Internship posted. Students can now apply.');
        redirect('company/internships.php');
    }
}

$page_title = 'Post an Internship';
require __DIR__ . '/../includes/header.php';
?>

<div class="ic-container ic-section ic-narrow-page">
  <header class="ic-page-head">
    <div>
      <p class="ic-eyebrow">New internship</p>
      <h1>Tell students what the role involves.</h1>
    </div>
  </header>

  <?php if ($errors): ?>
    <div class="ic-flash ic-flash-error" role="alert">
      <?php foreach ($errors as $e): ?><div><?= clean($e) ?></div><?php endforeach; ?>
    </div>
  <?php endif; ?>

  <div class="ic-panel">
    <form method="POST" action="add_internship.php" novalidate>
      <input type="hidden" name="csrf_token" value="<?= clean(csrf_token()) ?>">

      <div class="ic-field">
        <label for="title">Role title</label>
        <input type="text" id="title" name="title" value="<?= clean($old['title']) ?>" placeholder="e.g. Frontend Development Intern" required>
      </div>

      <div class="ic-field">
        <label for="description">Description</label>
        <textarea id="description" name="description" rows="5" required><?= clean($old['description']) ?></textarea>
      </div>

      <div class="ic-field">
        <label for="skills_required">Skills required</label>
        <input type="text" id="skills_required" name="skills_required" value="<?= clean($old['skills_required']) ?>" placeholder="Comma separated, e.g. React, CSS, Git">
      </div>

      <div class="ic-field-pair">
        <div class="ic-field">
          <label for="location">Location</label>
          <input type="text" id="location" name="location" value="<?= clean($old['location']) ?>" placeholder="City, or Remote">
        </div>
        <div class="ic-field">
          <label for="work_mode">Work mode</label>
          <select id="work_mode" name="work_mode">
            <?php foreach (['Remote', 'Onsite', 'Hybrid'] as $m): ?>
              <option value="<?= $m ?>" <?= $old['work_mode'] === $m ? 'selected' : '' ?>><?= $m ?></option>
            <?php endforeach; ?>
          </select>
        </div>
      </div>

      <div class="ic-field-pair">
        <div class="ic-field">
          <label for="stipend">Stipend</label>
          <input type="text" id="stipend" name="stipend" value="<?= clean($old['stipend']) ?>" placeholder="e.g. ₹15,000/month">
        </div>
        <div class="ic-field">
          <label for="duration">Duration</label>
          <input type="text" id="duration" name="duration" value="<?= clean($old['duration']) ?>" placeholder="e.g. 3 months">
        </div>
      </div>

      <div class="ic-field">
        <label for="deadline">Application deadline</label>
        <input type="date" id="deadline" name="deadline" value="<?= clean($old['deadline']) ?>">
      </div>

      <button type="submit" class="ic-btn ic-btn-primary" data-loading-text="Posting…">Post internship</button>
    </form>
  </div>
</div>

<?php require __DIR__ . '/../includes/footer.php'; ?>
