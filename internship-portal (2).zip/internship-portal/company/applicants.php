<?php
require_once __DIR__ . '/../includes/auth.php';
require_role('company');

$pdo = getDBConnection();
$company = get_company_profile($pdo, current_user_id());
$valid_statuses = ['Applied', 'Under Review', 'Shortlisted', 'Interview', 'Selected', 'Rejected'];

if ($_SERVER['REQUEST_METHOD'] === 'POST' && $company) {
    if (!csrf_verify($_POST['csrf_token'] ?? '')) {
        set_flash('error', 'Your session expired. Please try again.');
        redirect('company/applicants.php' . (!empty($_POST['internship_id']) ? '?internship_id=' . (int) $_POST['internship_id'] : ''));
    }

    $application_id = (int) ($_POST['application_id'] ?? 0);
    $new_status = (string) ($_POST['status'] ?? '');

    // Ownership check: the application must belong to an internship this company posted.
    $check = $pdo->prepare("
        SELECT a.id FROM applications a
        JOIN internships i ON i.id = a.internship_id
        WHERE a.id = ? AND i.company_id = ?
    ");
    $check->execute([$application_id, $company['id']]);

    if ($check->fetch() && in_array($new_status, $valid_statuses, true)) {
        $upd = $pdo->prepare("UPDATE applications SET status = ? WHERE id = ?");
        $upd->execute([$new_status, $application_id]);
        set_flash('success', "Application marked as $new_status.");
    } else {
        set_flash('error', 'Could not update that application.');
    }
    redirect('company/applicants.php' . (!empty($_POST['internship_id']) ? '?internship_id=' . (int) $_POST['internship_id'] : ''));
}

$internship_id = isset($_GET['internship_id']) ? (int) $_GET['internship_id'] : 0;
$internship = null;
$applicants = [];

if ($company) {
    if ($internship_id) {
        $stmt = $pdo->prepare("SELECT * FROM internships WHERE id = ? AND company_id = ?");
        $stmt->execute([$internship_id, $company['id']]);
        $internship = $stmt->fetch();

        if ($internship) {
            $stmt = $pdo->prepare("
                SELECT a.*, s.college, s.department, s.year_of_study, s.skills, s.resume_path, u.full_name, u.email
                FROM applications a
                JOIN students s ON s.id = a.student_id
                JOIN users u ON u.id = s.user_id
                WHERE a.internship_id = ?
                ORDER BY a.applied_at DESC
            ");
            $stmt->execute([$internship_id]);
            $applicants = $stmt->fetchAll();
        }
    } else {
        $stmt = $pdo->prepare("
            SELECT a.*, s.college, s.department, s.year_of_study, s.skills, s.resume_path,
                   u.full_name, u.email, i.title AS internship_title
            FROM applications a
            JOIN students s ON s.id = a.student_id
            JOIN users u ON u.id = s.user_id
            JOIN internships i ON i.id = a.internship_id
            WHERE i.company_id = ?
            ORDER BY a.applied_at DESC
        ");
        $stmt->execute([$company['id']]);
        $applicants = $stmt->fetchAll();
    }
}

$page_title = $internship ? 'Applicants · ' . $internship['title'] : 'All Applicants';
require __DIR__ . '/../includes/header.php';
?>

<div class="ic-container ic-section">
  <header class="ic-page-head">
    <div>
      <p class="ic-eyebrow"><?= $internship ? 'Applicants' : 'All applicants' ?></p>
      <h1><?= $internship ? clean($internship['title']) : 'Everyone who applied.' ?></h1>
    </div>
  </header>
  <?php if ($internship_id && !$internship): ?>
    <div class="ic-flash ic-flash-error" role="alert">That internship could not be found.</div>
  <?php endif; ?>

  <?php if ($applicants): ?>
    <div class="ic-listing">
      <?php foreach ($applicants as $a): ?>
        <div class="ic-panel">
          <div style="display:flex;justify-content:space-between;align-items:start;gap:16px;flex-wrap:wrap">
            <div>
              <h3 style="margin-bottom:2px"><?= clean($a['full_name']) ?></h3>
              <div style="color:var(--text-muted);font-size:.88rem">
                <?= clean($a['email']) ?><?= $a['college'] ? ' · ' . clean($a['college']) : '' ?><?= $a['year_of_study'] ? ' · ' . clean($a['year_of_study']) : '' ?>
              </div>
              <?php if (!empty($a['internship_title'])): ?>
                <div style="color:var(--text-muted);font-size:.82rem;margin-top:4px">Applied for: <?= clean($a['internship_title']) ?></div>
              <?php endif; ?>
              <?php if ($a['skills']): ?>
                <div class="ic-skills">
                  <?php foreach (array_slice(array_map('trim', explode(',', $a['skills'])), 0, 8) as $s): ?>
                    <?php if ($s !== ''): ?><span class="ic-skill-chip"><?= clean($s) ?></span><?php endif; ?>
                  <?php endforeach; ?>
                </div>
              <?php endif; ?>
              <?php if ($a['resume_path']): ?>
                <div style="margin-top:8px"><a href="<?= clean(url('resume.php?student=' . (int) $a['student_id'])) ?>" target="_blank" rel="noopener">View resume →</a></div>
              <?php endif; ?>
            </div>
            <span class="ic-badge badge-<?= str_replace(' ', '-', $a['status']) ?>"><?= clean($a['status']) ?></span>
          </div>

          <form method="POST" action="applicants.php<?= $internship_id ? '?internship_id=' . $internship_id : '' ?>" style="display:flex;gap:8px;margin-top:16px;flex-wrap:wrap;align-items:center">
            <input type="hidden" name="csrf_token" value="<?= clean(csrf_token()) ?>">
            <input type="hidden" name="application_id" value="<?= (int) $a['id'] ?>">
            <input type="hidden" name="internship_id" value="<?= $internship_id ?: (int) ($a['internship_id'] ?? 0) ?>">
            <select name="status" style="width:auto">
              <?php foreach ($valid_statuses as $s): ?>
                <option value="<?= $s ?>" <?= $a['status'] === $s ? 'selected' : '' ?>><?= $s ?></option>
              <?php endforeach; ?>
            </select>
            <button type="submit" class="ic-btn ic-btn-outline ic-btn-sm" data-loading-text="Updating…">Update status</button>

            <?php if ($a['status'] !== 'Shortlisted'): ?>
              <button type="submit" name="status" value="Shortlisted" class="ic-btn ic-btn-primary ic-btn-sm" data-loading-text="Shortlisting…">Shortlist</button>
            <?php endif; ?>
            <?php if ($a['status'] !== 'Rejected'): ?>
              <button type="submit" name="status" value="Rejected" class="ic-btn ic-btn-danger ic-btn-sm" data-confirm="Reject this application? The student will see this status update." data-loading-text="Rejecting…">Reject</button>
            <?php endif; ?>
          </form>
        </div>
      <?php endforeach; ?>
    </div>
  <?php else: ?>
    <div class="ic-empty"><p>No applicants yet<?= $internship ? ' for this role' : '' ?>.</p></div>
  <?php endif; ?>
</div>

<?php require __DIR__ . '/../includes/footer.php'; ?>
