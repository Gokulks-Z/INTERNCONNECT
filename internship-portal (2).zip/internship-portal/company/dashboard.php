<?php
require_once __DIR__ . '/../includes/auth.php';
require_role('company');

$pdo = getDBConnection();
$company = get_company_profile($pdo, current_user_id());
$companyId = $company ? (int) $company['id'] : 0;

$stats = ['posted' => 0, 'open' => 0, 'applicants' => 0, 'pending' => 0, 'shortlisted' => 0];
$pipeline = array_fill_keys(['Applied', 'Under Review', 'Shortlisted', 'Interview', 'Selected', 'Rejected'], 0);
$recentApplications = [];
$postings = [];

if ($companyId) {
    $stmt = $pdo->prepare('SELECT status, COUNT(*) AS c FROM internships WHERE company_id = ? GROUP BY status');
    $stmt->execute([$companyId]);
    foreach ($stmt->fetchAll() as $row) {
        $stats['posted'] += (int) $row['c'];
        if ($row['status'] === 'Open') {
            $stats['open'] = (int) $row['c'];
        }
    }

    $stmt = $pdo->prepare(
        'SELECT a.status, COUNT(*) AS c FROM applications a
         JOIN internships i ON i.id = a.internship_id
         WHERE i.company_id = ? GROUP BY a.status'
    );
    $stmt->execute([$companyId]);
    foreach ($stmt->fetchAll() as $row) {
        if (isset($pipeline[$row['status']])) {
            $pipeline[$row['status']] = (int) $row['c'];
        }
        $stats['applicants'] += (int) $row['c'];
    }
    $stats['pending'] = $pipeline['Applied'] + $pipeline['Under Review'];
    $stats['shortlisted'] = $pipeline['Shortlisted'];

    $stmt = $pdo->prepare(
        'SELECT a.status, a.applied_at, u.full_name, i.id AS internship_id, i.title
         FROM applications a
         JOIN internships i ON i.id = a.internship_id
         JOIN students s ON s.id = a.student_id
         JOIN users u ON u.id = s.user_id
         WHERE i.company_id = ?
         ORDER BY a.updated_at DESC LIMIT 6'
    );
    $stmt->execute([$companyId]);
    $recentApplications = $stmt->fetchAll();

    $stmt = $pdo->prepare(
        'SELECT i.id, i.title, i.status, i.posted_at,
                (SELECT COUNT(*) FROM applications a WHERE a.internship_id = i.id) AS applicant_count
         FROM internships i WHERE i.company_id = ?
         ORDER BY i.posted_at DESC LIMIT 5'
    );
    $stmt->execute([$companyId]);
    $postings = $stmt->fetchAll();
}

$pipelineMax = max(1, max($pipeline));
$page_title = 'Dashboard';
require __DIR__ . '/../includes/header.php';
?>

<div class="ic-container ic-section">
  <header class="ic-page-head">
    <div>
      <p class="ic-eyebrow">Hiring workspace</p>
      <h1><?= $company ? clean($company['company_name']) : 'Your company' ?>, at a glance.</h1>
    </div>
    <a href="add_internship.php" class="ic-btn ic-btn-primary">Post an internship</a>
  </header>

  <div class="ic-stats-grid">
    <div class="ic-stat"><b><?= $stats['open'] ?></b><span>Open internships</span></div>
    <div class="ic-stat"><b><?= $stats['applicants'] ?></b><span>Total applicants</span></div>
    <div class="ic-stat"><b><?= $stats['pending'] ?></b><span>Awaiting review</span></div>
    <div class="ic-stat"><b><?= $stats['shortlisted'] ?></b><span>Shortlisted</span></div>
  </div>

  <div class="ic-dash-grid ic-dash-grid-even">
    <section class="ic-panel">
      <h2>Applicant pipeline</h2>
      <?php if ($stats['applicants']): ?>
        <ul class="ic-pipeline">
          <?php foreach ($pipeline as $stage => $count): ?>
            <li>
              <span><?= clean($stage) ?></span>
              <div class="ic-meter ic-meter-<?= clean(str_replace(' ', '-', $stage)) ?>"><span style="width:<?= (int) round($count / $pipelineMax * 100) ?>%"></span></div>
              <b><?= $count ?></b>
            </li>
          <?php endforeach; ?>
        </ul>
      <?php else: ?>
        <div class="ic-empty"><p>No applicants yet. They appear here as students apply.</p></div>
      <?php endif; ?>
    </section>

    <section class="ic-panel">
      <div class="ic-block-head">
        <h2>Recent applications</h2>
        <a class="ic-btn ic-btn-ghost ic-btn-sm" href="applicants.php">Review all</a>
      </div>
      <?php if ($recentApplications): ?>
        <ul class="ic-activity-list ic-activity-list-flat">
          <?php foreach ($recentApplications as $row): ?>
            <li>
              <div>
                <strong><?= clean($row['full_name']) ?></strong>
                <span><a href="applicants.php?internship_id=<?= (int) $row['internship_id'] ?>"><?= clean($row['title']) ?></a> · <?= clean(date('d M', strtotime($row['applied_at']))) ?></span>
              </div>
              <span class="ic-badge badge-<?= clean(str_replace(' ', '-', $row['status'])) ?>"><?= clean($row['status']) ?></span>
            </li>
          <?php endforeach; ?>
        </ul>
      <?php else: ?>
        <div class="ic-empty"><p>Nothing to review yet.</p></div>
      <?php endif; ?>
    </section>
  </div>

  <section class="ic-block">
    <div class="ic-block-head">
      <h2>Your postings</h2>
      <a class="ic-btn ic-btn-ghost ic-btn-sm" href="internships.php">Manage</a>
    </div>
    <?php if ($postings): ?>
      <div class="ic-table-wrap">
        <table class="ic-table">
          <thead><tr><th>Role</th><th>Posted</th><th>Applicants</th><th>Status</th><th><span class="ic-sr-only">Actions</span></th></tr></thead>
          <tbody>
            <?php foreach ($postings as $posting): ?>
              <tr>
                <td data-label="Role"><?= clean($posting['title']) ?></td>
                <td data-label="Posted"><?= clean(date('d M Y', strtotime($posting['posted_at']))) ?></td>
                <td data-label="Applicants"><?= (int) $posting['applicant_count'] ?></td>
                <td data-label="Status"><span class="ic-badge badge-<?= clean($posting['status']) ?>"><?= clean($posting['status']) ?></span></td>
                <td><a href="applicants.php?internship_id=<?= (int) $posting['id'] ?>" class="ic-btn ic-btn-ghost ic-btn-sm">Applicants</a></td>
              </tr>
            <?php endforeach; ?>
          </tbody>
        </table>
      </div>
    <?php else: ?>
      <div class="ic-empty ic-panel">
        <h2>No internships posted</h2>
        <p>Post your first role and students can start applying.</p>
        <a href="add_internship.php" class="ic-btn ic-btn-primary">Post an internship</a>
      </div>
    <?php endif; ?>
  </section>
</div>

<?php require __DIR__ . '/../includes/footer.php'; ?>
