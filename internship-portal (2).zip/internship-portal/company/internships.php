<?php
require_once __DIR__ . '/../includes/auth.php';
require_role('company');

$pdo = getDBConnection();
$company = get_company_profile($pdo, current_user_id());

if ($_SERVER['REQUEST_METHOD'] === 'POST' && $company) {
    if (!csrf_verify($_POST['csrf_token'] ?? '')) {
        set_flash('error', 'Your session expired. Please try again.');
        redirect('company/internships.php');
    }

    $id = (int) ($_POST['internship_id'] ?? 0);
    $action = (string) ($_POST['action'] ?? '');

    // Ownership check: only ever touch internships that belong to this company.
    $own = $pdo->prepare("SELECT id, status FROM internships WHERE id = ? AND company_id = ?");
    $own->execute([$id, $company['id']]);
    $row = $own->fetch();

    if ($row && $action === 'toggle') {
        $new = $row['status'] === 'Open' ? 'Closed' : 'Open';
        $upd = $pdo->prepare("UPDATE internships SET status = ? WHERE id = ?");
        $upd->execute([$new, $id]);
        set_flash('success', "Internship marked as $new.");
    } elseif ($row && $action === 'delete') {
        $del = $pdo->prepare("DELETE FROM internships WHERE id = ?");
        $del->execute([$id]);
        set_flash('success', 'Internship deleted.');
    } else {
        set_flash('error', 'That internship could not be found.');
    }
    redirect('company/internships.php');
}

$internships = [];
if ($company) {
    $stmt = $pdo->prepare("
        SELECT i.*, (SELECT COUNT(*) FROM applications a WHERE a.internship_id = i.id) AS applicant_count
        FROM internships i
        WHERE i.company_id = ?
        ORDER BY i.posted_at DESC
    ");
    $stmt->execute([$company['id']]);
    $internships = $stmt->fetchAll();
}

$page_title = 'My Internships';
require __DIR__ . '/../includes/header.php';
?>

<div class="ic-container ic-section">
  <header class="ic-page-head">
    <div>
      <p class="ic-eyebrow">Hiring workspace</p>
      <h1>Your internships.</h1>
    </div>
    <a href="add_internship.php" class="ic-btn ic-btn-primary">Post an internship</a>
  </header>

  <?php if ($internships): ?>
    <div class="ic-table-wrap">
      <table class="ic-table">
        <thead><tr><th>Role</th><th>Location</th><th>Applicants</th><th>Status</th><th>Posted</th><th></th></tr></thead>
        <tbody>
        <?php foreach ($internships as $i): ?>
          <tr>
            <td><?= clean($i['title']) ?></td>
            <td><?= clean($i['location'] ?: $i['work_mode']) ?></td>
            <td><?= (int) $i['applicant_count'] ?></td>
            <td><span class="ic-badge badge-<?= $i['status'] ?>"><?= clean($i['status']) ?></span></td>
            <td><?= date('d M Y', strtotime($i['posted_at'])) ?></td>
            <td>
              <div style="display:flex;gap:6px;flex-wrap:wrap">
                <a href="applicants.php?internship_id=<?= (int) $i['id'] ?>" class="ic-btn ic-btn-ghost ic-btn-sm">Applicants</a>
                <form method="POST" action="internships.php" style="display:inline">
                  <input type="hidden" name="csrf_token" value="<?= clean(csrf_token()) ?>">
                  <input type="hidden" name="internship_id" value="<?= (int) $i['id'] ?>">
                  <input type="hidden" name="action" value="toggle">
                  <button type="submit" class="ic-btn ic-btn-outline ic-btn-sm" data-loading-text="Updating…"><?= $i['status'] === 'Open' ? 'Close' : 'Reopen' ?></button>
                </form>
                <form method="POST" action="internships.php" style="display:inline">
                  <input type="hidden" name="csrf_token" value="<?= clean(csrf_token()) ?>">
                  <input type="hidden" name="internship_id" value="<?= (int) $i['id'] ?>">
                  <input type="hidden" name="action" value="delete">
                  <button type="submit" class="ic-btn ic-btn-danger ic-btn-sm" data-confirm="Delete this internship and all its applications? This cannot be undone." data-loading-text="Deleting…">Delete</button>
                </form>
              </div>
            </td>
          </tr>
        <?php endforeach; ?>
        </tbody>
      </table>
    </div>
  <?php else: ?>
    <div class="ic-empty"><p>You haven't posted any internships yet. <a href="add_internship.php">Post your first one</a>.</p></div>
  <?php endif; ?>
</div>

<?php require __DIR__ . '/../includes/footer.php'; ?>
