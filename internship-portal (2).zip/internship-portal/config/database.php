<?php
/**
 * Database connection (PDO + MySQL).
 * Credentials come from the environment or config/env.local.php, never from
 * this file. See config/env.local.example.php.
 */

function database_unavailable(): void
{
    http_response_code(503);
    echo '<!DOCTYPE html><html lang="en"><head><meta charset="UTF-8">'
        . '<meta name="viewport" content="width=device-width, initial-scale=1">'
        . '<title>InternConnect</title></head>'
        . '<body style="font-family:system-ui,sans-serif;background:#0B0D0C;color:#F4F0E8;'
        . 'display:grid;place-items:center;min-height:100vh;margin:0;padding:24px;text-align:center">'
        . '<div><h1 style="font-size:1.4rem;margin:0 0 8px">We could not reach the database</h1>'
        . '<p style="color:#A8AAA2;margin:0">Please try again in a moment.</p></div></body></html>';
    exit;
}

function database_connect(bool $fatal)
{
    static $pdo = null;
    if ($pdo instanceof PDO) {
        return $pdo;
    }

    $host = env_value('DB_HOST');
    $name = env_value('DB_NAME');
    $user = env_value('DB_USER');

    if (!$host || !$name || !$user || !extension_loaded('pdo_mysql')) {
        error_log('InternConnect: database settings are incomplete or pdo_mysql is not loaded.');
        if ($fatal) {
            database_unavailable();
        }
        return null;
    }

    try {
        $dsn = 'mysql:host=' . $host . ';port=' . (int) env_value('DB_PORT', 3306)
            . ';dbname=' . $name . ';charset=utf8mb4';
        $pdo = new PDO($dsn, $user, (string) env_value('DB_PASS', ''), [
            PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            PDO::ATTR_EMULATE_PREPARES   => false,
            PDO::ATTR_TIMEOUT            => 8,
        ]);
        return $pdo;
    } catch (PDOException $e) {
        error_log('InternConnect: database connection failed (code ' . $e->getCode() . ').');
        if ($fatal) {
            database_unavailable();
        }
        return null;
    }
}

function getDBConnection(): PDO
{
    return database_connect(true);
}

/** For public pages that should still render if the database is down. */
function getDBConnectionOrNull(): ?PDO
{
    return database_connect(false);
}
