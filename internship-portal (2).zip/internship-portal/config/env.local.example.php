<?php
/**
 * Copy this file to config/env.local.php and fill in real values.
 * config/env.local.php is a PHP file, so the web server executes it instead of
 * showing its contents, but keep it out of version control and out of zips.
 */
return [
    // Database
    'DB_HOST' => 'db01.dbhost.dev',
    'DB_PORT' => '5051',
    'DB_NAME' => 'db_454vqet2r',
    'DB_USER' => 'user_454vqet2r',
    'DB_PASS' => 'p454vqet2r',

    // Public address of this site, used for links in emails (no trailing slash)
    'APP_URL' => 'https://0f970dbf7b23-0af410f0-8080.ws6.app',

    // Resend (https://resend.com): API key and a verified sender address
    'RESEND_API_KEY'    => 're_QNmoYrDa_MDQcd61859VeKEjBGuFQPEJw',
    'RESEND_FROM_EMAIL' => 'no-reply@your-verified-domain.example',
    'RESEND_FROM_NAME'  => 'InternConnect',
];
