-- InternConnect schema. Safe to run more than once: every statement uses
-- CREATE TABLE IF NOT EXISTS and indexes are declared inside the tables.
-- Run it against the database your hosting already provides; it does not
-- create or select a database.

CREATE TABLE IF NOT EXISTS users (
  id INT AUTO_INCREMENT PRIMARY KEY,
  full_name VARCHAR(100) NOT NULL,
  email VARCHAR(150) NOT NULL UNIQUE,
  password VARCHAR(255) NOT NULL,
  role ENUM('student','company') NOT NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS students (
  id INT AUTO_INCREMENT PRIMARY KEY,
  user_id INT NOT NULL UNIQUE,
  college VARCHAR(150) DEFAULT NULL,
  department VARCHAR(100) DEFAULT NULL,
  year_of_study VARCHAR(20) DEFAULT NULL,
  skills TEXT DEFAULT NULL,
  bio TEXT DEFAULT NULL,
  resume_path VARCHAR(255) DEFAULT NULL,
  resume_headline VARCHAR(180) DEFAULT NULL,
  project_title VARCHAR(180) DEFAULT NULL,
  project_description TEXT DEFAULT NULL,
  project_url VARCHAR(500) DEFAULT NULL,
  project_tech_stack VARCHAR(255) DEFAULT NULL,
  FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS companies (
  id INT AUTO_INCREMENT PRIMARY KEY,
  user_id INT NOT NULL UNIQUE,
  company_name VARCHAR(150) NOT NULL,
  industry VARCHAR(100) DEFAULT NULL,
  website VARCHAR(255) DEFAULT NULL,
  about TEXT DEFAULT NULL,
  FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS internships (
  id INT AUTO_INCREMENT PRIMARY KEY,
  company_id INT NOT NULL,
  title VARCHAR(150) NOT NULL,
  description TEXT NOT NULL,
  skills_required VARCHAR(255) DEFAULT NULL,
  location VARCHAR(100) DEFAULT NULL,
  work_mode ENUM('Remote','Onsite','Hybrid') DEFAULT 'Remote',
  stipend VARCHAR(50) DEFAULT NULL,
  duration VARCHAR(50) DEFAULT NULL,
  deadline DATE DEFAULT NULL,
  status ENUM('Open','Closed') DEFAULT 'Open',
  posted_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  KEY idx_internships_status (status),
  KEY idx_internships_location (location),
  FOREIGN KEY (company_id) REFERENCES companies(id) ON DELETE CASCADE
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS applications (
  id INT AUTO_INCREMENT PRIMARY KEY,
  student_id INT NOT NULL,
  internship_id INT NOT NULL,
  status ENUM('Applied','Under Review','Shortlisted','Interview','Selected','Rejected') DEFAULT 'Applied',
  applied_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  UNIQUE KEY unique_application (student_id, internship_id),
  KEY idx_applications_status (status),
  KEY idx_applications_updated (updated_at),
  FOREIGN KEY (student_id) REFERENCES students(id) ON DELETE CASCADE,
  FOREIGN KEY (internship_id) REFERENCES internships(id) ON DELETE CASCADE
) ENGINE=InnoDB;

-- Only a SHA-256 hash of each reset token is stored, never the token itself.
CREATE TABLE IF NOT EXISTS password_resets (
  id INT AUTO_INCREMENT PRIMARY KEY,
  user_id INT NOT NULL,
  token_hash CHAR(64) NOT NULL,
  expires_at DATETIME NOT NULL,
  used TINYINT(1) NOT NULL DEFAULT 0,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  KEY idx_password_resets_token (token_hash),
  KEY idx_password_resets_user (user_id),
  CONSTRAINT fk_password_resets_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS support_queries (
  id INT AUTO_INCREMENT PRIMARY KEY,
  user_id INT NULL,
  name VARCHAR(100) NOT NULL,
  email VARCHAR(150) NOT NULL,
  category VARCHAR(40) NOT NULL,
  subject VARCHAR(150) NOT NULL,
  message TEXT NOT NULL,
  reference VARCHAR(100) DEFAULT NULL,
  status ENUM('Open','In Progress','Resolved','Closed') NOT NULL DEFAULT 'Open',
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  KEY idx_support_queries_email (email),
  KEY idx_support_queries_user (user_id),
  KEY idx_support_queries_status (status),
  CONSTRAINT fk_support_queries_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE SET NULL
) ENGINE=InnoDB;
