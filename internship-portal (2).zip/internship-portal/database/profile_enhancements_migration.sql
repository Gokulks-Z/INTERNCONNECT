-- Run once on an existing InternConnect database to add profile enhancements.
-- Does not alter users, credentials, authentication, or existing data.
ALTER TABLE students
  ADD COLUMN resume_headline VARCHAR(180) DEFAULT NULL,
  ADD COLUMN project_title VARCHAR(180) DEFAULT NULL,
  ADD COLUMN project_description TEXT DEFAULT NULL,
  ADD COLUMN project_url VARCHAR(500) DEFAULT NULL,
  ADD COLUMN project_tech_stack VARCHAR(255) DEFAULT NULL;
