<?php
require_once __DIR__ . '/includes/auth.php';
require_once __DIR__ . '/includes/schema.php';
require_once __DIR__ . '/includes/mail.php';

redirect_if_logged_in();

const RESET_TOKEN_LIFETIME = 3600;
const RESET_MAX_PER_QUARTER_HOUR = 3;

$errors = [];
$oldEmail = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!csrf_verify($_POST['csrf_token'] ?? '')) {
        $errors[] = 'Your session expired. Please try again.';
    }

    $oldEmail = strtolower(trim((string) ($_POST['email'] ?? '')));
    if (!filter_var($oldEmail, FILTER_VALIDATE_EMAIL)) {
        $errors[] = 'Enter a valid email address.';
    }

    if (!$errors && !throttle_allowed('reset-request', 5, 900)) {
        $errors[] = 'Too many requests. Please wait a few minutes and try again.';
    }

    if (!$errors) {
        throttle_hit('reset-request');

        $pdo = getDBConnection();
        ensure_aux_tables($pdo);

        $stmt = $pdo->prepare('SELECT id, full_name FROM users WHERE email = ? LIMIT 1');
        $stmt->execute([$oldEmail]);
        $user = $stmt->fetch();

        if ($user) {
            $recent = $pdo->prepare(
                'SELECT COUNT(*) FROM password_resets
                 WHERE user_id = ? AND created_at > (NOW() - INTERVAL 15 MINUTE)'
            );
            $recent->execute([$user['id']]);

            if ((int) $recent->fetchColumn() < RESET_MAX_PER_QUARTER_HOUR) {
                $token = bin2hex(random_bytes(32));

                $pdo->prepare('UPDATE password_resets SET used = 1 WHERE user_id = ? AND used = 0')
                    ->execute([$user['id']]);
                $pdo->prepare('INSERT INTO password_resets (user_id, token_hash, expires_at) VALUES (?, ?, ?)')
                    ->execute([
                        $user['id'],
                        hash('sha256', $token),
                        gmdate('Y-m-d H:i:s', time() + RESET_TOKEN_LIFETIME),
                    ]);

                // The link is built from APP_URL only. Building it from the
                // request's Host header would let an attacker poison it.
                $resetUrl = app_url('reset-password.php?token=' . $token);
                if ($resetUrl === '') {
                    error_log('InternConnect: APP_URL is not set, password reset email was not sent.');
                } else {
                    send_password_reset_email($oldEmail, $user['full_name'], $resetUrl);
                }
            }
        }

        // Identical outcome whether or not the account exists.
        redirect('forgot-password.php?sent=1');
    }
}

$submitted = isset($_GET['sent']);
$page_title = 'Forgot password';
require __DIR__ . '/includes/header.php';
?>

<div class="ic-auth">
  <aside class="ic-auth-side ic-dark" aria-hidden="true">
    <p class="ic-auth-kicker">Account recovery</p>
    <h2>Locked out for a moment.</h2>
    <p>Reset links are single use and expire after an hour.</p>
  </aside>

  <div class="ic-auth-main">
    <div class="ic-panel ic-panel-narrow">
      <?php if ($submitted): ?>
        <h1 class="ic-auth-title">Check your inbox</h1>
        <p>If that email is associated with an account, we have sent password reset instructions.</p>
        <p class="ic-auth-foot"><a href="login.php">Back to log in</a></p>
      <?php else: ?>
        <h1 class="ic-auth-title">Reset your password</h1>
        <p>Enter the email you registered with and we will send you a reset link.</p>

        <?php if ($errors): ?>
          <div class="ic-flash ic-flash-error" role="alert">
            <?php foreach ($errors as $error): ?><div><?= clean($error) ?></div><?php endforeach; ?>
          </div>
        <?php endif; ?>

        <form method="POST" action="forgot-password.php" novalidate>
          <?= csrf_field() ?>
          <div class="ic-field" id="field-email">
            <label for="email">Email</label>
            <input type="email" id="email" name="email" value="<?= clean($oldEmail) ?>" required autofocus autocomplete="email">
            <div class="ic-error-text">Enter a valid email address.</div>
          </div>
          <button type="submit" class="ic-btn ic-btn-primary ic-btn-block" data-loading-text="Sending…">Send reset link</button>
        </form>
        <p class="ic-auth-foot"><a href="login.php">Back to log in</a></p>
      <?php endif; ?>
    </div>
  </div>
</div>

<?php require __DIR__ . '/includes/footer.php'; ?>
