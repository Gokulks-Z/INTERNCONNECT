<?php
/**
 * Application bootstrap: error policy, security headers, the single session
 * start, authentication helpers, CSRF and request throttling.
 * Every page requires this file before producing any output.
 */

require_once __DIR__ . '/helpers.php';

ini_set('display_errors', '0');
ini_set('log_errors', '1');
error_reporting(E_ALL);

if (!headers_sent()) {
    header('X-Content-Type-Options: nosniff');
    header('X-Frame-Options: SAMEORIGIN');
    header('Referrer-Policy: same-origin');
}

if (session_status() === PHP_SESSION_NONE && !headers_sent()) {
    $sessionDir = storage_path('sessions');
    if (is_dir($sessionDir) && is_writable($sessionDir)) {
        session_save_path($sessionDir);
    }

    ini_set('session.use_strict_mode', '1');
    ini_set('session.use_only_cookies', '1');
    ini_set('session.use_trans_sid', '0');

    session_name('ic_session');
    session_set_cookie_params([
        'lifetime' => 0,
        'path'     => app_base_path() === '' ? '/' : app_base_path() . '/',
        'secure'   => is_https_request(),
        'httponly' => true,
        'samesite' => 'Lax',
    ]);
    session_start();
}

require_once __DIR__ . '/../config/database.php';

/* ---------------- Identity ---------------- */

function is_logged_in(): bool
{
    return isset($_SESSION['user_id']);
}

function current_role(): ?string
{
    return $_SESSION['role'] ?? null;
}

function current_user_id(): ?int
{
    return isset($_SESSION['user_id']) ? (int) $_SESSION['user_id'] : null;
}

function dashboard_path_for_current_user(): ?string
{
    switch (current_role()) {
        case 'student':
            return 'student/dashboard.php';
        case 'company':
            return 'company/dashboard.php';
        default:
            return null;
    }
}

/** Fully ends a session, including its cookie. */
function force_logout(): void
{
    $_SESSION = [];
    if (ini_get('session.use_cookies') && !headers_sent()) {
        $params = session_get_cookie_params();
        setcookie(session_name(), '', [
            'expires'  => time() - 42000,
            'path'     => $params['path'],
            'domain'   => $params['domain'],
            'secure'   => $params['secure'],
            'httponly' => $params['httponly'],
            'samesite' => 'Lax',
        ]);
    }
    if (session_status() === PHP_SESSION_ACTIVE) {
        session_destroy();
    }
}

/* ---------------- Redirects ---------------- */

/**
 * Redirects to a path relative to the application root, for example
 * "student/dashboard.php". External URLs are refused, so a user-supplied value
 * can never turn this into an open redirect.
 */
function redirect(string $path): void
{
    $path = str_replace(["\r", "\n"], '', trim($path));
    if (preg_match('#^[a-z][a-z0-9+.-]*:#i', $path) || strpos($path, '//') === 0) {
        $path = '';
    }
    $path = ltrim(str_replace('\\', '/', $path), '/');
    $path = preg_replace('#(\.\.?/)+#', '', $path);

    header('Location: ' . url((string) $path));
    exit;
}

/** Sends logged-in users to their own dashboard; clears broken sessions. */
function redirect_if_logged_in(): void
{
    if (!is_logged_in()) {
        return;
    }
    $target = dashboard_path_for_current_user();
    if ($target === null) {
        force_logout();
        return;
    }
    redirect($target);
}

function require_role(string $role): void
{
    if (!is_logged_in()) {
        set_flash('error', 'Please log in to continue.');
        redirect('login.php');
    }

    if (current_role() !== $role) {
        $target = dashboard_path_for_current_user();
        if ($target === null) {
            force_logout();
            redirect('login.php');
        }
        set_flash('error', 'You do not have access to that page.');
        redirect($target);
    }
}

/* ---------------- Flash messages ---------------- */

function set_flash(string $type, string $message): void
{
    $_SESSION['flash'] = ['type' => $type === 'error' ? 'error' : 'success', 'message' => $message];
}

function get_flash(): ?array
{
    if (empty($_SESSION['flash'])) {
        return null;
    }
    $flash = $_SESSION['flash'];
    unset($_SESSION['flash']);
    return $flash;
}

/* ---------------- Profiles ---------------- */

function get_student_profile(PDO $pdo, int $userId)
{
    $stmt = $pdo->prepare('SELECT * FROM students WHERE user_id = ?');
    $stmt->execute([$userId]);
    return $stmt->fetch();
}

function get_company_profile(PDO $pdo, int $userId)
{
    $stmt = $pdo->prepare('SELECT * FROM companies WHERE user_id = ?');
    $stmt->execute([$userId]);
    return $stmt->fetch();
}

/* ---------------- CSRF ---------------- */

function csrf_token(): string
{
    if (empty($_SESSION['csrf_token'])) {
        $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
    }
    return $_SESSION['csrf_token'];
}

function csrf_verify($token): bool
{
    return !empty($_SESSION['csrf_token']) && hash_equals($_SESSION['csrf_token'], (string) $token);
}

function csrf_field(): string
{
    return '<input type="hidden" name="csrf_token" value="' . clean(csrf_token()) . '">';
}

/* ---------------- Request throttling (per session) ---------------- */

function throttle_key(string $bucket): string
{
    return 'throttle_' . md5(strtolower($bucket));
}

function throttle_allowed(string $bucket, int $limit = 5, int $windowSeconds = 600): bool
{
    $key = throttle_key($bucket);
    $entry = $_SESSION[$key] ?? ['count' => 0, 'first' => time()];
    if (time() - $entry['first'] > $windowSeconds) {
        $entry = ['count' => 0, 'first' => time()];
    }
    $_SESSION[$key] = $entry;
    return $entry['count'] < $limit;
}

function throttle_hit(string $bucket): void
{
    $key = throttle_key($bucket);
    $entry = $_SESSION[$key] ?? ['count' => 0, 'first' => time()];
    $entry['count']++;
    $_SESSION[$key] = $entry;
}

function throttle_clear(string $bucket): void
{
    unset($_SESSION[throttle_key($bucket)]);
}
