</main>

<footer class="ic-footer ic-dark">
  <div class="ic-footer-inner">
    <div class="ic-footer-brand">
      <strong>InternConnect</strong>
      <span>Discover. Apply. Track. Launch.</span>
    </div>
    <nav class="ic-footer-links" aria-label="Footer">
      <a href="<?= clean(url('support.php')) ?>">Support</a>
      <?php if (!is_logged_in()): ?>
        <a href="<?= clean(url('login.php')) ?>">Log in</a>
        <a href="<?= clean(url('register.php')) ?>">Create account</a>
      <?php else: ?>
        <a href="<?= clean(url(dashboard_path_for_current_user() ?? 'index.php')) ?>">Dashboard</a>
      <?php endif; ?>
    </nav>
    <span class="ic-footer-copy">© <?= date('Y') ?> InternConnect</span>
  </div>
</footer>

<div class="ic-modal-overlay" id="ic-confirm-overlay" hidden>
  <div class="ic-modal" role="alertdialog" aria-modal="true" aria-labelledby="ic-confirm-title" aria-describedby="ic-confirm-body">
    <h3 id="ic-confirm-title">Please confirm</h3>
    <p id="ic-confirm-body">Are you sure?</p>
    <div class="ic-modal-actions">
      <button type="button" class="ic-btn ic-btn-ghost" id="ic-confirm-cancel">Cancel</button>
      <button type="button" class="ic-btn ic-btn-danger" id="ic-confirm-accept">Confirm</button>
    </div>
  </div>
</div>

<script>window.IC_BASE = <?= json_encode(app_base_path() . '/') ?>;</script>
<script src="<?= clean(url('js/neural-cloud.js')) ?>?v=neural-cloud-refine-20261012"></script>
<script src="<?= clean(url('js/main.js')) ?>?v=neural-cloud-refine-20261012"></script>
<script src="<?= clean(url('js/validation.js')) ?>?v=passphrase-12-20261011"></script>
<script src="<?= clean(url('js/tracker.js')) ?>?v=neural-cloud-refine-20261012"></script>
</body>
</html>
