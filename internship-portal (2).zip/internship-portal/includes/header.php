<?php
/**
 * Shared page header. Pages set $page_title (string) before including.
 * Requires includes/auth.php to be loaded first.
 */
$page_title = $page_title ?? 'InternConnect';
$flash = get_flash();
$currentScript = basename($_SERVER['SCRIPT_NAME'] ?? '');

if (!function_exists('nav_link')) {
    function nav_link(string $path, string $label, string $currentScript): string
    {
        $active = basename($path) === $currentScript;
        return '<a class="ic-nav-link' . ($active ? ' is-active' : '') . '" href="' . clean(url($path)) . '"'
            . ($active ? ' aria-current="page"' : '') . '>' . clean($label) . '</a>';
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="theme-color" content="#0B0D0C">
<meta name="description" content="InternConnect connects students with internships and gives companies a clear way to review applicants.">
<title><?= clean($page_title) ?> · InternConnect</title>
<link rel="icon" type="image/svg+xml" href="<?= clean(url('favicon.svg')) ?>">
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Sora:wght@400;600;700;800&family=Karla:wght@400;500;600;700&display=swap" rel="stylesheet">
<link rel="stylesheet" href="<?= clean(url('css/style.css')) ?>?v=neural-cloud-refine-20261012">
</head>
<body class="page-<?= clean(preg_replace('/[^a-z0-9-]/i', '', pathinfo($currentScript, PATHINFO_FILENAME))) ?>">
<div class="ic-neural-cloud-layer" aria-hidden="true"></div>
<a href="#main-content" class="ic-skip-link">Skip to main content</a>

<header class="ic-navbar ic-dark" id="ic-navbar">
  <div class="ic-navbar-inner">
    <a href="<?= clean(url('index.php')) ?>" class="ic-brand" aria-label="InternConnect home">
      <svg class="ic-brand-mark" viewBox="0 0 32 32" width="30" height="30" aria-hidden="true">
        <path class="ic-brand-edges" d="M16 5 L5 26 L27 26 Z" fill="none" stroke="currentColor" stroke-width="1.4" stroke-linejoin="round"/>
        <circle class="ic-brand-node ic-brand-node-a" cx="16" cy="5" r="3"/>
        <circle class="ic-brand-node ic-brand-node-b" cx="5" cy="26" r="3"/>
        <circle class="ic-brand-node ic-brand-node-c" cx="27" cy="26" r="3"/>
      </svg>
      <span class="ic-brand-word">Intern<span>Connect</span></span>
    </a>

    <button type="button" id="ic-nav-toggle" class="ic-nav-toggle" aria-label="Open menu" aria-expanded="false" aria-controls="ic-nav-panel">
      <span class="ic-nav-toggle-bar"></span>
      <span class="ic-nav-toggle-bar"></span>
      <span class="ic-nav-toggle-bar"></span>
    </button>

    <div class="ic-nav-overlay" id="ic-nav-overlay" hidden></div>

    <nav class="ic-nav-links" id="ic-nav-panel" aria-label="Main navigation">
      <span class="ic-nav-indicator" aria-hidden="true"></span>
      <?php if (is_logged_in() && current_role() === 'student'): ?>
        <?= nav_link('student/dashboard.php', 'Dashboard', $currentScript) ?>
        <?= nav_link('student/internships.php', 'Internships', $currentScript) ?>
        <?= nav_link('student/applications.php', 'Applications', $currentScript) ?>
        <?= nav_link('student/profile.php', 'Profile', $currentScript) ?>
        <?= nav_link('support.php', 'Support', $currentScript) ?>
        <a href="<?= clean(url('logout.php')) ?>" class="ic-btn ic-btn-ghost ic-btn-sm">Log out</a>
      <?php elseif (is_logged_in() && current_role() === 'company'): ?>
        <?= nav_link('company/dashboard.php', 'Dashboard', $currentScript) ?>
        <?= nav_link('company/internships.php', 'My internships', $currentScript) ?>
        <?= nav_link('company/applicants.php', 'Applicants', $currentScript) ?>
        <?= nav_link('company/add_internship.php', 'Post internship', $currentScript) ?>
        <?= nav_link('support.php', 'Support', $currentScript) ?>
        <a href="<?= clean(url('logout.php')) ?>" class="ic-btn ic-btn-ghost ic-btn-sm">Log out</a>
      <?php else: ?>
        <a class="ic-nav-link" href="<?= clean(url('index.php#how-it-works')) ?>">How it works</a>
        <?= nav_link('support.php', 'Support', $currentScript) ?>
        <?= nav_link('login.php', 'Log in', $currentScript) ?>
        <a href="<?= clean(url('register.php')) ?>" class="ic-btn ic-btn-primary ic-btn-sm">Get started</a>
      <?php endif; ?>
    </nav>
  </div>
</header>

<div class="ic-toast-region" id="ic-toast-region" aria-live="polite" aria-atomic="true">
  <?php if ($flash): ?>
    <div class="ic-toast ic-toast-<?= clean($flash['type']) ?>" role="status">
      <span class="ic-toast-icon" aria-hidden="true"><?= $flash['type'] === 'success' ? '&#10003;' : '!' ?></span>
      <span class="ic-toast-msg"><?= clean($flash['message']) ?></span>
      <button type="button" class="ic-toast-close" aria-label="Dismiss notification">&times;</button>
      <span class="ic-toast-timer" aria-hidden="true"></span>
    </div>
  <?php endif; ?>
</div>

<main class="ic-main" id="main-content">
