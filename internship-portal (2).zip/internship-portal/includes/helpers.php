<?php
/**
 * Shared helpers: environment, paths, text utilities.
 * Loaded first by includes/auth.php. Nothing here produces output.
 */

function project_root(): string
{
    return dirname(__DIR__);
}

/** Reads a setting from real environment variables, then local config files. */
function env_value(string $key, $default = null)
{
    static $fileValues = null;

    if ($fileValues === null) {
        $fileValues = [];

        $local = project_root() . '/config/env.local.php';
        if (is_file($local)) {
            $data = include $local;
            if (is_array($data)) {
                $fileValues = $data;
            }
        }

        // A .env placed one level above the web root is also honoured, so
        // secrets never have to sit inside the publicly served folder.
        $dotenv = dirname(project_root()) . '/.env';
        if (is_readable($dotenv)) {
            $lines = file($dotenv, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES) ?: [];
            foreach ($lines as $line) {
                $line = trim($line);
                if ($line === '' || $line[0] === '#' || strpos($line, '=') === false) {
                    continue;
                }
                [$name, $value] = explode('=', $line, 2);
                $fileValues[trim($name)] = trim(trim($value), "\"'");
            }
        }
    }

    $real = getenv($key);
    if ($real !== false && $real !== '') {
        return $real;
    }
    if (isset($fileValues[$key]) && $fileValues[$key] !== '') {
        return $fileValues[$key];
    }
    return $default;
}

/* ---------------- Text helpers (work without mbstring) ---------------- */

function safe_strlen(string $text): int
{
    if (function_exists('mb_strlen')) {
        return mb_strlen($text, 'UTF-8');
    }
    $count = preg_match_all('/./su', $text);
    return $count === false ? strlen($text) : $count;
}

function safe_excerpt(string $text, int $limit = 160): string
{
    $text = trim((string) preg_replace('/\s+/u', ' ', $text));
    if ($limit < 2 || safe_strlen($text) <= $limit) {
        return $text;
    }
    if (function_exists('mb_substr')) {
        $cut = mb_substr($text, 0, $limit - 1, 'UTF-8');
    } elseif (preg_match('/^.{0,' . ($limit - 1) . '}/su', $text, $match)) {
        $cut = $match[0];
    } else {
        $cut = substr($text, 0, $limit - 1);
    }
    return rtrim($cut) . '…';
}

function clean($value): string
{
    return htmlspecialchars(trim((string) ($value ?? '')), ENT_QUOTES, 'UTF-8');
}

/* ---------------- Paths and URLs ---------------- */

/** URL path prefix of the app when it is not served from the domain root. */
function app_base_path(): string
{
    static $base = null;
    if ($base !== null) {
        return $base;
    }
    $dir = rtrim(str_replace('\\', '/', dirname($_SERVER['SCRIPT_NAME'] ?? '/')), '/');
    foreach (['/student', '/company'] as $folder) {
        if (substr($dir, -strlen($folder)) === $folder) {
            $dir = substr($dir, 0, -strlen($folder));
            break;
        }
    }
    return $base = $dir;
}

/** Root-relative URL for an app path such as "css/style.css". */
function url(string $path = ''): string
{
    return app_base_path() . '/' . ltrim($path, '/');
}

function is_https_request(): bool
{
    if (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') {
        return true;
    }
    return strtolower((string) ($_SERVER['HTTP_X_FORWARDED_PROTO'] ?? '')) === 'https';
}

/** Absolute site URL from APP_URL; empty when not configured. */
function app_url(string $path = ''): string
{
    $configured = rtrim((string) env_value('APP_URL', ''), '/');
    if ($configured === '' || !preg_match('#^https?://#i', $configured)) {
        return '';
    }
    return $configured . '/' . ltrim($path, '/');
}

/* ---------------- Private storage (sessions, resumes) ---------------- */

function storage_root(): string
{
    static $root = null;
    if ($root !== null) {
        return $root;
    }

    $candidates = [];
    $configured = env_value('STORAGE_PATH');
    if ($configured) {
        $candidates[] = rtrim((string) $configured, '/\\');
    }
    $candidates[] = dirname(project_root()) . '/internconnect-storage';
    $candidates[] = project_root() . '/storage';

    foreach ($candidates as $dir) {
        if (!is_dir($dir)) {
            @mkdir($dir, 0775, true);
        }
        if (is_dir($dir) && is_writable($dir)) {
            return $root = $dir;
        }
    }
    return $root = sys_get_temp_dir();
}

function storage_path(string $subfolder = ''): string
{
    $path = storage_root();
    if ($subfolder !== '') {
        $path .= '/' . trim($subfolder, '/');
        if (!is_dir($path)) {
            @mkdir($path, 0775, true);
        }
    }
    return $path;
}

/* ---------------- Student profile helpers ---------------- */

/** Splits a free-text skills field into a clean, de-duplicated list. */
function parse_skills(string $raw, int $maxSkills = 20, int $maxLength = 30): array
{
    $skills = [];
    foreach (explode(',', $raw) as $skill) {
        $skill = trim((string) preg_replace('/\s+/u', ' ', $skill));
        if ($skill === '' || safe_strlen($skill) > $maxLength) {
            continue;
        }
        $key = strtolower($skill);
        if (!isset($skills[$key])) {
            $skills[$key] = $skill;
        }
        if (count($skills) >= $maxSkills) {
            break;
        }
    }
    return array_values($skills);
}

/**
 * Profile completeness from the columns that exist on `students`.
 * @return array{percent:int,missing:string[]}
 */
function student_completion($student): array
{
    $fields = [
        'college'       => 'college',
        'department'    => 'department',
        'year_of_study' => 'year of study',
        'skills'        => 'skills',
        'bio'           => 'short bio',
        'resume_path'   => 'resume',
    ];
    $missing = [];
    foreach ($fields as $column => $label) {
        if (empty($student[$column])) {
            $missing[] = $label;
        }
    }
    $done = count($fields) - count($missing);
    return ['percent' => (int) round($done / count($fields) * 100), 'missing' => $missing];
}
