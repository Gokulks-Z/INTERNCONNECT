<?php
/**
 * Transactional email through the Resend HTTPS API.
 * Pages call send_password_reset_email(); the transport details stay here.
 * Failures are logged without secrets and reported to callers as false, so a
 * mail problem is never visible to (or exploitable by) the visitor.
 */

const RESEND_ENDPOINT = 'https://api.resend.com/emails';

/** @return array{key:string,from_email:string,from_name:string}|null */
function resend_configuration(): ?array
{
    $key = trim((string) env_value('RESEND_API_KEY', ''));
    $fromEmail = trim((string) env_value('RESEND_FROM_EMAIL', ''));

    if ($key === '' || !filter_var($fromEmail, FILTER_VALIDATE_EMAIL)) {
        return null;
    }

    $fromName = trim((string) env_value('RESEND_FROM_NAME', 'InternConnect'));
    $fromName = trim(preg_replace('/[\r\n"<>]+/', '', $fromName) ?? '');

    return [
        'key'        => $key,
        'from_email' => $fromEmail,
        'from_name'  => $fromName !== '' ? $fromName : 'InternConnect',
    ];
}

/**
 * POSTs JSON and returns [httpStatus, decodedBody|null].
 * Uses cURL when available, otherwise PHP streams.
 */
function resend_post(string $apiKey, array $payload): array
{
    $body = json_encode($payload, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE);
    if ($body === false) {
        return [0, null];
    }

    $headers = [
        'Authorization: Bearer ' . $apiKey,
        'Content-Type: application/json',
        'User-Agent: InternConnect/1.0',
    ];

    if (function_exists('curl_init')) {
        $handle = curl_init(RESEND_ENDPOINT);
        if ($handle === false) {
            return [0, null];
        }
        curl_setopt_array($handle, [
            CURLOPT_POST           => true,
            CURLOPT_POSTFIELDS     => $body,
            CURLOPT_HTTPHEADER     => $headers,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_CONNECTTIMEOUT => 5,
            CURLOPT_TIMEOUT        => 12,
            CURLOPT_FOLLOWLOCATION => false,
        ]);
        $raw = curl_exec($handle);
        $status = (int) curl_getinfo($handle, CURLINFO_HTTP_CODE);
        if ($raw === false) {
            return [0, null];
        }
        $decoded = json_decode((string) $raw, true);
        return [$status, is_array($decoded) ? $decoded : null];
    }

    if (!ini_get('allow_url_fopen')) {
        return [0, null];
    }

    $context = stream_context_create([
        'http' => [
            'method'        => 'POST',
            'header'        => implode("\r\n", $headers),
            'content'       => $body,
            'timeout'       => 12,
            'ignore_errors' => true,
        ],
    ]);
    $raw = @file_get_contents(RESEND_ENDPOINT, false, $context);
    if ($raw === false) {
        return [0, null];
    }

    $status = 0;
    $responseHeaders = function_exists('http_get_last_response_headers')
        ? (http_get_last_response_headers() ?? [])
        : ($http_response_header ?? []);
    if (!empty($responseHeaders[0]) && preg_match('#\s(\d{3})\s#', $responseHeaders[0], $match)) {
        $status = (int) $match[1];
    }
    $decoded = json_decode($raw, true);
    return [$status, is_array($decoded) ? $decoded : null];
}

function send_email(string $toEmail, string $subject, string $html, string $text): bool
{
    $config = resend_configuration();
    if ($config === null) {
        error_log('InternConnect mail: RESEND_API_KEY or RESEND_FROM_EMAIL is missing or invalid.');
        return false;
    }
    if (!filter_var($toEmail, FILTER_VALIDATE_EMAIL)) {
        return false;
    }

    [$status, $response] = resend_post($config['key'], [
        'from'    => $config['from_name'] . ' <' . $config['from_email'] . '>',
        'to'      => [$toEmail],
        'subject' => $subject,
        'html'    => $html,
        'text'    => $text,
    ]);

    if ($status >= 200 && $status < 300 && isset($response['id'])) {
        return true;
    }

    error_log('InternConnect mail: Resend request failed with HTTP status ' . $status . '.');
    return false;
}

function send_password_reset_email(string $toEmail, string $toName, string $resetUrl): bool
{
    $safeName = clean($toName);
    $safeUrl = clean($resetUrl);

    $html = '<!DOCTYPE html><html><body style="margin:0;padding:0;background:#F4F0E8;font-family:Arial,Helvetica,sans-serif;">'
        . '<table role="presentation" width="100%" cellpadding="0" cellspacing="0" style="background:#F4F0E8;padding:32px 16px;"><tr><td align="center">'
        . '<table role="presentation" width="480" cellpadding="0" cellspacing="0" style="max-width:480px;background:#FFFFFF;border-radius:12px;overflow:hidden;">'
        . '<tr><td style="background:#0B0D0C;padding:20px 28px;color:#F4F0E8;font-size:18px;font-weight:bold;">InternConnect</td></tr>'
        . '<tr><td style="padding:28px;">'
        . '<p style="margin:0 0 16px;color:#171512;font-size:16px;">Hi ' . $safeName . ',</p>'
        . '<p style="margin:0 0 22px;color:#44403A;font-size:14px;line-height:1.6;">Someone asked to reset the password for your InternConnect account. '
        . 'Use the button below to choose a new one. The link works once and expires in 1 hour.</p>'
        . '<table role="presentation" cellpadding="0" cellspacing="0"><tr><td style="border-radius:999px;background:#C8F05A;">'
        . '<a href="' . $safeUrl . '" style="display:inline-block;padding:12px 26px;color:#15190A;text-decoration:none;font-weight:bold;font-size:14px;">Reset password</a>'
        . '</td></tr></table>'
        . '<p style="margin:24px 0 0;color:#767168;font-size:12px;line-height:1.6;">If the button does not work, paste this address into your browser:<br>'
        . '<span style="word-break:break-all;">' . $safeUrl . '</span></p>'
        . '<p style="margin:18px 0 0;color:#767168;font-size:12px;line-height:1.6;">If you did not request this, you can ignore this email. Your password stays the same.</p>'
        . '</td></tr></table></td></tr></table></body></html>';

    $text = "Hi {$toName},\n\n"
        . "Someone asked to reset the password for your InternConnect account.\n"
        . "Choose a new password here (works once, expires in 1 hour):\n{$resetUrl}\n\n"
        . "If you did not request this, you can ignore this email.\n";

    return send_email($toEmail, 'Reset your InternConnect password', $html, $text);
}
