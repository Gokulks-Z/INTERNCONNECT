<?php
/**
 * Creates the two tables added after the original release if they are
 * missing. Safe to run repeatedly; runs at most once per session.
 */
function ensure_aux_tables(PDO $pdo): void
{
    if (!empty($_SESSION['aux_schema_ready'])) {
        return;
    }

    try {
        $pdo->exec(
            'CREATE TABLE IF NOT EXISTS password_resets (
                id INT AUTO_INCREMENT PRIMARY KEY,
                user_id INT NOT NULL,
                token_hash CHAR(64) NOT NULL,
                expires_at DATETIME NOT NULL,
                used TINYINT(1) NOT NULL DEFAULT 0,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                KEY idx_password_resets_token (token_hash),
                KEY idx_password_resets_user (user_id),
                CONSTRAINT fk_password_resets_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
            ) ENGINE=InnoDB'
        );
        $pdo->exec(
            'CREATE TABLE IF NOT EXISTS support_queries (
                id INT AUTO_INCREMENT PRIMARY KEY,
                user_id INT NULL,
                name VARCHAR(100) NOT NULL,
                email VARCHAR(150) NOT NULL,
                category VARCHAR(40) NOT NULL,
                subject VARCHAR(150) NOT NULL,
                message TEXT NOT NULL,
                reference VARCHAR(100) DEFAULT NULL,
                status ENUM(\'Open\',\'In Progress\',\'Resolved\',\'Closed\') NOT NULL DEFAULT \'Open\',
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
                KEY idx_support_queries_email (email),
                KEY idx_support_queries_user (user_id),
                KEY idx_support_queries_status (status),
                CONSTRAINT fk_support_queries_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE SET NULL
            ) ENGINE=InnoDB'
        );
        $_SESSION['aux_schema_ready'] = true;
    } catch (PDOException $e) {
        error_log('InternConnect: could not verify auxiliary tables (code ' . $e->getCode() . ').');
    }
}
