<?php
/**
 * Triangular opportunity tracker (Student profile, Opportunity, Company review).
 *
 * Expects before include:
 *   $trackerState   string  idle|applied|review|shortlisted|interview|selected|rejected
 *   $trackerCaption string  optional line shown under the diagram
 *   $trackerCompact bool    optional, hides the caption/info line
 *   $trackerLive    bool    optional, lets js/tracker.js update it from the activity feed
 */
require_once __DIR__ . '/tracker_state.php';

$trackerState   = $trackerState ?? 'idle';
$trackerCaption = $trackerCaption ?? '';
$trackerCompact = !empty($trackerCompact);
$trackerLive    = !empty($trackerLive);
$trackerLabel   = tracker_state_label($trackerState);
?>
<div class="ic-tracker<?= $trackerCompact ? ' is-compact' : '' ?>" data-state="<?= clean($trackerState) ?>"<?= $trackerLive ? ' data-live="1"' : '' ?>>
  <svg viewBox="0 0 360 336" role="img" aria-label="Application tracker. Current stage: <?= clean($trackerLabel) ?>">
    <g class="ic-t-edges" fill="none">
      <path class="ic-t-spoke" d="M180 196 L180 52"/>
      <path class="ic-t-spoke" d="M180 196 L60 268"/>
      <path class="ic-t-spoke" d="M180 196 L300 268"/>
      <path class="ic-t-edge ic-t-edge-a" d="M180 52 L60 268"/>
      <path class="ic-t-edge ic-t-edge-b" d="M60 268 L300 268"/>
      <path class="ic-t-edge ic-t-edge-c" d="M300 268 L180 52"/>
    </g>

    <g class="ic-t-particles">
      <circle class="ic-t-particle ic-t-particle-a" r="3.4"><animateMotion dur="3.8s" repeatCount="indefinite" path="M180 52 L60 268"/></circle>
      <circle class="ic-t-particle ic-t-particle-a" r="3.4"><animateMotion dur="3.8s" begin="-1.9s" repeatCount="indefinite" path="M180 52 L60 268"/></circle>
      <circle class="ic-t-particle ic-t-particle-b" r="3.4"><animateMotion dur="3.4s" repeatCount="indefinite" path="M60 268 L300 268"/></circle>
      <circle class="ic-t-particle ic-t-particle-b" r="3.4"><animateMotion dur="3.4s" begin="-1.7s" repeatCount="indefinite" path="M60 268 L300 268"/></circle>
      <circle class="ic-t-particle ic-t-particle-c" r="3.4"><animateMotion dur="3.8s" repeatCount="indefinite" path="M300 268 L180 52"/></circle>
      <circle class="ic-t-particle ic-t-particle-c" r="3.4"><animateMotion dur="3.8s" begin="-1.9s" repeatCount="indefinite" path="M300 268 L180 52"/></circle>
    </g>

    <g class="ic-t-hub">
      <circle class="ic-t-hub-ring" cx="180" cy="196" r="38"/>
      <circle class="ic-t-hub-core" cx="180" cy="196" r="30"/>
      <text class="ic-t-hub-kicker" x="180" y="190" text-anchor="middle">STATUS</text>
      <text class="ic-t-hub-label" x="180" y="206" text-anchor="middle"><?= clean($trackerLabel) ?></text>
    </g>

    <g class="ic-t-node" data-node="profile" tabindex="0" role="button" aria-label="Student profile">
      <circle class="ic-t-node-halo" cx="180" cy="52" r="30"/>
      <circle class="ic-t-node-disc" cx="180" cy="52" r="20"/>
      <circle class="ic-t-node-dot" cx="180" cy="52" r="6"/>
      <text class="ic-t-node-label" x="180" y="18" text-anchor="middle">Student profile</text>
    </g>
    <g class="ic-t-node" data-node="opportunity" tabindex="0" role="button" aria-label="Internship opportunity">
      <circle class="ic-t-node-halo" cx="60" cy="268" r="30"/>
      <circle class="ic-t-node-disc" cx="60" cy="268" r="20"/>
      <circle class="ic-t-node-dot" cx="60" cy="268" r="6"/>
      <text class="ic-t-node-label" x="60" y="316" text-anchor="middle">Opportunity</text>
    </g>
    <g class="ic-t-node" data-node="company" tabindex="0" role="button" aria-label="Company review">
      <circle class="ic-t-node-halo" cx="300" cy="268" r="30"/>
      <circle class="ic-t-node-disc" cx="300" cy="268" r="20"/>
      <circle class="ic-t-node-dot" cx="300" cy="268" r="6"/>
      <text class="ic-t-node-label" x="300" y="316" text-anchor="middle">Company review</text>
    </g>
  </svg>
  <?php if (!$trackerCompact): ?>
    <p class="ic-tracker-info" aria-live="polite" data-default="<?= clean($trackerCaption) ?>"><?= clean($trackerCaption) ?></p>
  <?php endif; ?>
</div>
