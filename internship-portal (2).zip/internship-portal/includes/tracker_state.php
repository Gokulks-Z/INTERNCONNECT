<?php
/** Maps application statuses to tracker states. Functions only, no output. */

function tracker_state_from_status(?string $status): string
{
    $map = [
        'Applied'      => 'applied',
        'Under Review' => 'review',
        'Shortlisted'  => 'shortlisted',
        'Interview'    => 'interview',
        'Selected'     => 'selected',
        'Rejected'     => 'rejected',
    ];
    return $map[$status ?? ''] ?? 'idle';
}

function tracker_state_label(string $state): string
{
    $labels = [
        'idle'        => 'Ready',
        'applied'     => 'Applied',
        'review'      => 'Under Review',
        'shortlisted' => 'Shortlisted',
        'interview'   => 'Interview',
        'selected'    => 'Selected',
        'rejected'    => 'Rejected',
    ];
    return $labels[$state] ?? 'Ready';
}
