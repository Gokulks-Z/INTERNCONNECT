<?php
require_once __DIR__ . '/includes/auth.php';
require_once __DIR__ . '/includes/tracker_state.php';

redirect_if_logged_in();

$counts = ['internships' => 0, 'companies' => 0, 'students' => 0];
$featured = [];
$latestState = 'idle';

$pdo = getDBConnectionOrNull();
if ($pdo !== null) {
    try {
        $counts['internships'] = (int) $pdo->query("SELECT COUNT(*) FROM internships WHERE status = 'Open'")->fetchColumn();
        $counts['companies']   = (int) $pdo->query('SELECT COUNT(*) FROM companies')->fetchColumn();
        $counts['students']    = (int) $pdo->query('SELECT COUNT(*) FROM students')->fetchColumn();

        $featured = $pdo->query(
            "SELECT i.id, i.title, i.description, i.location, i.work_mode, i.duration, i.stipend, c.company_name
             FROM internships i JOIN companies c ON c.id = i.company_id
             WHERE i.status = 'Open' ORDER BY i.posted_at DESC LIMIT 3"
        )->fetchAll();

        $latest = $pdo->query('SELECT status FROM applications ORDER BY updated_at DESC LIMIT 1')->fetchColumn();
        $latestState = tracker_state_from_status($latest ?: null);
    } catch (PDOException $e) {
        error_log('InternConnect: home page query failed (code ' . $e->getCode() . ').');
    }
}

$hasSnapshot = array_sum($counts) > 0;
$trackerState = $latestState;
$trackerLive = true;
$trackerCaption = $latestState === 'idle'
    ? 'Select a point on the triangle to see what happens there.'
    : 'Live view: the centre shows the latest stage reached on the platform.';

$page_title = 'Find your next internship';
require __DIR__ . '/includes/header.php';
?>

<section class="ic-hero ic-dark">
  <div class="ic-container ic-hero-grid">
    <div class="ic-hero-copy">
      <p class="ic-eyebrow"><span class="ic-eyebrow-dot" aria-hidden="true"></span>Internships for students, applicants for companies</p>
      <h1>Skip the traditional ladder. Build the elevator.</h1>
      <p class="lead">An exclusive matchmaking infrastructure designed to bypass entry-level friction and place exceptional minds directly into high-impact corporate and tech environments.</p>
      <div class="ic-hero-actions">
        <a href="register.php?role=student" class="ic-btn ic-btn-primary">Join as a student</a>
        <a href="register.php?role=company" class="ic-btn ic-btn-outline">Post internships</a>
      </div>
      <ol class="ic-hero-path" aria-label="How it works">
        <li>Discover</li><li>Apply</li><li>Track</li><li>Launch</li>
      </ol>
    </div>
    <div class="ic-hero-visual">
      <?php include __DIR__ . '/includes/tracker.php'; ?>
    </div>
  </div>
</section>

<section class="ic-snapshot" aria-label="Platform snapshot">
  <div class="ic-container">
    <?php if ($hasSnapshot): ?>
      <ul>
        <li><b><?= $counts['internships'] ?></b><span>open internships</span></li>
        <li><b><?= $counts['companies'] ?></b><span>companies</span></li>
        <li><b><?= $counts['students'] ?></b><span>students</span></li>
      </ul>
    <?php else: ?>
      <p>A new platform. The first companies and students to join shape what it becomes.</p>
    <?php endif; ?>
  </div>
</section>

<section class="ic-section">
  <div class="ic-container">
    <div class="ic-block-head">
      <h2>Latest internships</h2>
      <?php if ($featured): ?><a href="login.php" class="ic-btn ic-btn-ghost ic-btn-sm">Log in to apply</a><?php endif; ?>
    </div>
    <?php if ($featured): ?>
      <div class="ic-card-grid ic-card-grid-3">
        <?php foreach ($featured as $item): ?>
          <article class="ic-feature ic-card-light">
            <p class="ic-feature-meta"><?= clean($item['company_name']) ?></p>
            <h3><?= clean($item['title']) ?></h3>
            <p><?= clean(safe_excerpt($item['description'], 130)) ?></p>
            <ul class="ic-chip-row">
              <li><?= clean($item['location'] ?: $item['work_mode']) ?></li>
              <?php if ($item['duration']): ?><li><?= clean($item['duration']) ?></li><?php endif; ?>
              <?php if ($item['stipend']): ?><li><?= clean($item['stipend']) ?></li><?php endif; ?>
            </ul>
          </article>
        <?php endforeach; ?>
      </div>
    <?php else: ?>
      <div class="ic-empty ic-panel">
        <h3>No internships available yet</h3>
        <p>Companies are just getting started. New roles appear here as soon as they are posted.</p>
      </div>
    <?php endif; ?>
  </div>
</section>

<section class="ic-section ic-section-tint" id="how-it-works">
  <div class="ic-container">
    <h2>How it works</h2>
    <ol class="ic-steps-row">
      <li><span>01</span><h3>Discover</h3><p>Browse open internships and filter by skill, location and work mode.</p></li>
      <li><span>02</span><h3>Apply</h3><p>One profile, one resume, one click. No re-typing the same details.</p></li>
      <li><span>03</span><h3>Track</h3><p>See exactly which stage each application has reached.</p></li>
      <li><span>04</span><h3>Launch</h3><p>When a company selects you, your application says so.</p></li>
    </ol>
  </div>
</section>

<section class="ic-section">
  <div class="ic-container">
    <h2>The application journey</h2>
    <p class="ic-section-lead">Every application moves through the same stages, and both sides see the same status.</p>
    <ol class="ic-journey">
      <li><i></i>Applied</li>
      <li><i></i>Under Review</li>
      <li><i></i>Shortlisted</li>
      <li><i></i>Interview</li>
      <li class="is-end"><i></i>Selected <em>or</em> Rejected</li>
    </ol>
  </div>
</section>

<section class="ic-section ic-section-tint">
  <div class="ic-container ic-split">
    <div class="ic-panel">
      <p class="ic-eyebrow">For students</p>
      <h2>One profile, every application.</h2>
      <ul class="ic-check-list">
        <li>Keep skills and resume in one place</li>
        <li>Search and filter open internships</li>
        <li>Follow each application's stage</li>
      </ul>
      <a href="register.php?role=student" class="ic-btn ic-btn-primary">Create a student account</a>
    </div>
    <div class="ic-panel">
      <p class="ic-eyebrow">For companies</p>
      <h2>Applicants without the spreadsheet.</h2>
      <ul class="ic-check-list">
        <li>Post internships and close them when filled</li>
        <li>Review applicants and open their resumes</li>
        <li>Shortlist, interview, select or reject</li>
      </ul>
      <a href="register.php?role=company" class="ic-btn ic-btn-ghost">Create a company account</a>
    </div>
  </div>
</section>

<section class="ic-section">
  <div class="ic-container">
    <div class="ic-block-head">
      <h2>Recent activity</h2>
      <span class="ic-live-note" id="ic-feed-status">Updates automatically</span>
    </div>
    <ul class="ic-feed" id="ic-activity-feed" data-endpoint="<?= clean(url('activity.php')) ?>" aria-live="polite">
      <li class="ic-feed-empty">Loading recent activity…</li>
    </ul>
    <noscript><p>Recent activity needs JavaScript to load.</p></noscript>
  </div>
</section>

<section class="ic-section">
  <div class="ic-container">
    <div class="ic-cta-band ic-dark">
      <h2>Your next milestone starts with one profile.</h2>
      <p>Create an account in a minute and start applying, or post your first internship.</p>
      <div class="ic-hero-actions">
        <a href="register.php?role=student" class="ic-btn ic-btn-primary">Join as a student</a>
        <a href="register.php?role=company" class="ic-btn ic-btn-outline">Post internships</a>
      </div>
    </div>
  </div>
</section>

<?php require __DIR__ . '/includes/footer.php'; ?>
