/**
 * InternConnect interface behaviour.
 * Everything here enhances plain PHP pages: links and forms work without it.
 */
(function () {
  'use strict';

  var reducedMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
  var canHover = window.matchMedia('(hover: hover) and (pointer: fine)').matches;

  function qs(selector, scope) { return (scope || document).querySelector(selector); }
  function qsa(selector, scope) { return Array.prototype.slice.call((scope || document).querySelectorAll(selector)); }

  /* ---------------- Header: scroll state ---------------- */
  var navbar = qs('#ic-navbar');
  if (navbar) {
    var scrollQueued = false;
    var updateScrollState = function () {
      scrollQueued = false;
      navbar.classList.toggle('is-scrolled', window.scrollY > 8);
    };
    window.addEventListener('scroll', function () {
      if (!scrollQueued) { scrollQueued = true; window.requestAnimationFrame(updateScrollState); }
    }, { passive: true });
    updateScrollState();
  }

  /* ---------------- Mobile navigation ---------------- */
  var navToggle = qs('#ic-nav-toggle');
  var navPanel = qs('#ic-nav-panel');
  var navOverlay = qs('#ic-nav-overlay');
  var navHome = navPanel ? navPanel.parentNode : null;
  var navPanelNext = navPanel ? navPanel.nextSibling : null;
  var navToggleHome = navToggle ? navToggle.parentNode : null;
  var navToggleNext = navToggle ? navToggle.nextSibling : null;
  var navOverlayHome = navOverlay ? navOverlay.parentNode : null;
  var navOverlayNext = navOverlay ? navOverlay.nextSibling : null;

  // On phones, portal the fixed drawer and scrim to <body>. This avoids
  // transformed/isolated header ancestors trapping them below page content.
  function syncMobileNavPortal() {
    if (!navPanel || !navOverlay || !navHome || !navOverlayHome || !navToggle || !navToggleHome) return;
    var mobile = window.matchMedia('(max-width: 768px)').matches;
    if (mobile) {
      if (navOverlay.parentNode !== document.body) document.body.appendChild(navOverlay);
      if (navPanel.parentNode !== document.body) document.body.appendChild(navPanel);
      if (navToggle.parentNode !== document.body) document.body.appendChild(navToggle);
    } else {
      if (navToggle.parentNode !== navToggleHome) {
        navToggleHome.insertBefore(navToggle, navToggleNext && navToggleNext.parentNode === navToggleHome ? navToggleNext : null);
      }
      if (navOverlay.parentNode !== navOverlayHome) {
        navOverlayHome.insertBefore(navOverlay, navOverlayNext && navOverlayNext.parentNode === navOverlayHome ? navOverlayNext : null);
      }
      if (navPanel.parentNode !== navHome) {
        navHome.insertBefore(navPanel, navPanelNext && navPanelNext.parentNode === navHome ? navPanelNext : null);
      }
      navPanel.classList.remove('is-open');
      navOverlay.classList.remove('is-open');
      navOverlay.hidden = true;
      document.body.classList.remove('ic-no-scroll');
      if (navToggle) { navToggle.setAttribute('aria-expanded', 'false'); navToggle.setAttribute('aria-label', 'Open menu'); }
    }
  }
  syncMobileNavPortal();

  function setNavOpen(open) {
    if (!navToggle || !navPanel || !navOverlay) { return; }
    navPanel.classList.toggle('is-open', open);
    document.body.classList.toggle('ic-no-scroll', open);
    navToggle.setAttribute('aria-expanded', open ? 'true' : 'false');
    navToggle.setAttribute('aria-label', open ? 'Close menu' : 'Open menu');
    if (open) {
      navOverlay.hidden = false;
      window.requestAnimationFrame(function () { navOverlay.classList.add('is-open'); });
    } else {
      navOverlay.classList.remove('is-open');
      window.setTimeout(function () { if (!navPanel.classList.contains('is-open')) { navOverlay.hidden = true; } }, 300);
    }
  }

  if (navToggle && navPanel && navOverlay) {
    navToggle.addEventListener('click', function () { setNavOpen(!navPanel.classList.contains('is-open')); });
    navOverlay.addEventListener('click', function () { setNavOpen(false); });
    document.addEventListener('keydown', function (event) {
      if (event.key === 'Escape' && navPanel.classList.contains('is-open')) {
        setNavOpen(false);
        navToggle.focus();
      }
    });
    window.addEventListener('resize', function () {
      syncMobileNavPortal();
      if (window.innerWidth > 768 && navPanel.classList.contains('is-open')) { setNavOpen(false); }
    });
  }

  /* ---------------- Desktop navigation: gliding indicator ---------------- */
  var indicator = qs('.ic-nav-indicator');
  if (indicator && navPanel) {
    var links = qsa('.ic-nav-link', navPanel);
    var activeLink = qs('.ic-nav-link.is-active', navPanel);

    var clearNear = function () { links.forEach(function (link) { link.classList.remove('is-near'); }); };
    var moveIndicator = function (target) {
      if (!target || window.innerWidth <= 768) { indicator.classList.remove('is-ready'); return; }
      indicator.style.setProperty('--indicator-x', target.offsetLeft + 'px');
      indicator.style.setProperty('--indicator-w', target.offsetWidth + 'px');
      indicator.classList.add('is-ready');
    };
    var restoreIndicator = function () {
      clearNear();
      if (navbar) { navbar.removeAttribute('data-linking'); }
      moveIndicator(activeLink);
    };

    links.forEach(function (link, index) {
      var focusLink = function () {
        clearNear();
        if (links[index - 1]) { links[index - 1].classList.add('is-near'); }
        if (links[index + 1]) { links[index + 1].classList.add('is-near'); }
        moveIndicator(link);
        if (navbar) {
          navbar.setAttribute('data-linking', '');
          navbar.style.setProperty('--link-shift', (index * 0.5) + 'px');
        }
      };
      link.addEventListener('mouseenter', focusLink);
      link.addEventListener('focus', focusLink);
      link.addEventListener('blur', restoreIndicator);
    });
    navPanel.addEventListener('mouseleave', restoreIndicator);
    window.addEventListener('resize', restoreIndicator);
    window.requestAnimationFrame(restoreIndicator);
    if (document.fonts && document.fonts.ready) { document.fonts.ready.then(restoreIndicator); }
  }

  /* ---------------- Toasts ---------------- */
  var toastRegion = qs('#ic-toast-region');

  function dismissToast(toast) {
    if (!toast || toast.classList.contains('is-leaving')) { return; }
    toast.classList.add('is-leaving');
    window.setTimeout(function () { if (toast.parentNode) { toast.parentNode.removeChild(toast); } }, 260);
  }

  function wireToast(toast) {
    var timer = window.setTimeout(function () { dismissToast(toast); }, 5000);
    var close = qs('.ic-toast-close', toast);
    if (close) { close.addEventListener('click', function () { window.clearTimeout(timer); dismissToast(toast); }); }
    toast.addEventListener('mouseenter', function () {
      window.clearTimeout(timer);
      var bar = qs('.ic-toast-timer', toast);
      if (bar) { bar.style.animationPlayState = 'paused'; }
    });
    toast.addEventListener('mouseleave', function () {
      var bar = qs('.ic-toast-timer', toast);
      if (bar) { bar.style.animationPlayState = 'running'; }
      timer = window.setTimeout(function () { dismissToast(toast); }, 2500);
    });
  }

  /** Public helper: window.InternConnect.toast('success' | 'error', 'Message'). */
  function showToast(type, message) {
    if (!toastRegion) { return; }
    var toast = document.createElement('div');
    toast.className = 'ic-toast ic-toast-' + (type === 'error' ? 'error' : 'success');
    toast.setAttribute('role', 'status');

    var icon = document.createElement('span');
    icon.className = 'ic-toast-icon';
    icon.setAttribute('aria-hidden', 'true');
    icon.textContent = type === 'error' ? '!' : '\u2713';

    var text = document.createElement('span');
    text.className = 'ic-toast-msg';
    text.textContent = message;

    var close = document.createElement('button');
    close.type = 'button';
    close.className = 'ic-toast-close';
    close.setAttribute('aria-label', 'Dismiss notification');
    close.textContent = '\u00d7';

    var bar = document.createElement('span');
    bar.className = 'ic-toast-timer';
    bar.setAttribute('aria-hidden', 'true');

    [icon, text, close, bar].forEach(function (node) { toast.appendChild(node); });
    toastRegion.appendChild(toast);
    wireToast(toast);
  }

  window.InternConnect = window.InternConnect || {};
  window.InternConnect.toast = showToast;
  qsa('.ic-toast', toastRegion || document).forEach(wireToast);

  /* ---------------- Confirm dialog ---------------- */
  var overlay = qs('#ic-confirm-overlay');
  if (overlay) {
    var body = qs('#ic-confirm-body');
    var accept = qs('#ic-confirm-accept');
    var cancel = qs('#ic-confirm-cancel');
    var pending = null;
    var opener = null;

    var closeConfirm = function (restoreFocus) {
      overlay.classList.remove('is-open');
      window.setTimeout(function () { overlay.hidden = true; }, 220);
      pending = null;
      if (restoreFocus && opener && opener.focus) { opener.focus(); }
    };

    document.addEventListener('submit', function (event) {
      if (event.defaultPrevented) { return; }
      var form = event.target;
      var submitter = event.submitter;
      var message = (submitter && submitter.dataset.confirm) || form.dataset.confirm;
      if (!message || form.dataset.icConfirmed === '1') { return; }

      event.preventDefault();
      pending = { form: form, submitter: submitter || null };
      opener = submitter || document.activeElement;
      body.textContent = message;
      overlay.hidden = false;
      window.requestAnimationFrame(function () { overlay.classList.add('is-open'); accept.focus(); });
    }, true);

    accept.addEventListener('click', function () {
      if (!pending) { return; }
      var form = pending.form;
      var submitter = pending.submitter;
      form.dataset.icConfirmed = '1';
      closeConfirm(false);
      if (typeof form.requestSubmit === 'function') {
        try { form.requestSubmit(submitter || undefined); return; } catch (error) { /* fall through */ }
      }
      if (submitter && submitter.name) {
        var hidden = document.createElement('input');
        hidden.type = 'hidden';
        hidden.name = submitter.name;
        hidden.value = submitter.value;
        form.appendChild(hidden);
      }
      form.submit();
    });
    cancel.addEventListener('click', function () { closeConfirm(true); });
    overlay.addEventListener('click', function (event) { if (event.target === overlay) { closeConfirm(true); } });
    overlay.addEventListener('keydown', function (event) {
      if (event.key === 'Escape') { closeConfirm(true); return; }
      if (event.key === 'Tab') {
        var first = cancel;
        var last = accept;
        if (event.shiftKey && document.activeElement === first) { event.preventDefault(); last.focus(); }
        else if (!event.shiftKey && document.activeElement === last) { event.preventDefault(); first.focus(); }
      }
    });
  }

  /* ---------------- Loading state and double-submit protection ---------------- */
  function resetLoadingButtons() {
    qsa('.ic-btn.is-loading').forEach(function (button) {
      if (button.dataset.originalHtml !== undefined) { button.innerHTML = button.dataset.originalHtml; }
      button.classList.remove('is-loading');
      button.removeAttribute('aria-busy');
    });
    qsa('form[data-ic-submitting]').forEach(function (form) {
      form.removeAttribute('data-ic-submitting');
      delete form.dataset.icConfirmed;
    });
  }

  document.addEventListener('submit', function (event) {
    if (event.defaultPrevented) { return; }
    var form = event.target;
    if (form.dataset.icSubmitting === '1') { event.preventDefault(); return; }

    var button = event.submitter && event.submitter.classList.contains('ic-btn')
      ? event.submitter
      : qs('button[type="submit"].ic-btn', form);
    form.dataset.icSubmitting = '1';
    if (!button) { return; }

    button.dataset.originalHtml = button.innerHTML;
    button.classList.add('is-loading');
    button.setAttribute('aria-busy', 'true');
    var spinner = document.createElement('span');
    spinner.className = 'ic-btn-spinner';
    spinner.setAttribute('aria-hidden', 'true');
    button.textContent = '';
    button.appendChild(spinner);
    button.appendChild(document.createTextNode(button.dataset.loadingText || 'Please wait…'));
  });

  // Returning with the back button restores the page from cache; undo any stuck loading state.
  window.addEventListener('pageshow', function (event) { if (event.persisted) { resetLoadingButtons(); } });

  /* ---------------- Password visibility ---------------- */
  var eyeOpen = '<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" aria-hidden="true"><path d="M1 12s4-7 11-7 11 7 11 7-4 7-11 7S1 12 1 12Z"/><circle cx="12" cy="12" r="3"/></svg>';
  var eyeShut = '<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" aria-hidden="true"><path d="M3 3l18 18M10.6 10.6a3 3 0 0 0 4.2 4.2M9.4 5.3A11 11 0 0 1 12 5c7 0 11 7 11 7a13.3 13.3 0 0 1-3.1 3.8M6.3 6.5A13.6 13.6 0 0 0 1 12s4 7 11 7a10.8 10.8 0 0 0 4.2-.8"/></svg>';

  qsa('.ic-pw-toggle').forEach(function (button) {
    button.innerHTML = eyeOpen;
    button.addEventListener('click', function () {
      var input = qs('input', button.parentNode);
      if (!input) { return; }
      var reveal = input.type === 'password';
      input.type = reveal ? 'text' : 'password';
      button.setAttribute('aria-label', reveal ? 'Hide password' : 'Show password');
      button.innerHTML = reveal ? eyeShut : eyeOpen;
    });
  });

  /* ---------------- Scroll reveal ---------------- */
  if ('IntersectionObserver' in window && !reducedMotion) {
    var targets = qsa('.ic-feature, .ic-steps-row li, .ic-journey li, .ic-split > .ic-panel, .ic-stat, .ic-activity-list li, .ic-listing-card, .ic-application, .ic-mini-card, .ic-block, .ic-cta-band');
    var observer = new IntersectionObserver(function (entries) {
      entries.forEach(function (entry) {
        if (entry.isIntersecting) { entry.target.classList.add('is-in'); observer.unobserve(entry.target); }
      });
    }, { threshold: 0.12, rootMargin: '0px 0px -30px 0px' });

    var seen = new Map();
    targets.forEach(function (node) {
      var group = node.parentNode;
      var index = seen.get(group) || 0;
      seen.set(group, index + 1);
      node.style.setProperty('--reveal-delay', Math.min(index, 5) * 0.06 + 's');
      node.classList.add('ic-reveal');
      observer.observe(node);
    });
  }

  /* ---------------- Pointer light on cards ---------------- */
  if (canHover && !reducedMotion) {
    qsa('.ic-listing-card, .ic-stat, .ic-mini-card, .ic-feature').forEach(function (card) {
      card.classList.add('ic-card-light');
      var queued = false;
      card.addEventListener('pointermove', function (event) {
        if (queued) { return; }
        queued = true;
        window.requestAnimationFrame(function () {
          var rect = card.getBoundingClientRect();
          card.style.setProperty('--mx', (event.clientX - rect.left) + 'px');
          card.style.setProperty('--my', (event.clientY - rect.top) + 'px');
          queued = false;
        });
      });
    });
  }

  /* ---------------- Dashboard number count-up ---------------- */
  if ('IntersectionObserver' in window && !reducedMotion) {
    var counters = qsa('.ic-stat b').filter(function (node) { return /^\d+$/.test(node.textContent.trim()); });
    var counterObserver = new IntersectionObserver(function (entries) {
      entries.forEach(function (entry) {
        if (!entry.isIntersecting) { return; }
        counterObserver.unobserve(entry.target);
        var node = entry.target;
        var target = parseInt(node.textContent, 10);
        if (target < 2) { return; }
        var start = null;
        var step = function (timestamp) {
          if (start === null) { start = timestamp; }
          var progress = Math.min((timestamp - start) / 700, 1);
          node.textContent = Math.round((1 - Math.pow(1 - progress, 3)) * target);
          if (progress < 1) { window.requestAnimationFrame(step); } else { node.textContent = target; }
        };
        window.requestAnimationFrame(step);
      });
    }, { threshold: 0.4 });
    counters.forEach(function (node) { counterObserver.observe(node); });
  }
})();
