/* InternConnect Neural Cloud — lightweight continuous mesh, all pages. */
(() => {
  'use strict';
  const layer = document.querySelector('.ic-neural-cloud-layer');
  if (!layer || window.matchMedia('(prefers-reduced-motion: reduce)').matches) return;
  const canvas = document.createElement('canvas');
  canvas.className = 'ic-neural-cloud-canvas';
  canvas.setAttribute('aria-hidden', 'true');
  layer.appendChild(canvas);
  const ctx = canvas.getContext('2d', { alpha: true, desynchronized: true });
  if (!ctx) return;
  let w=0,h=0,dpr=1,nodes=[],raf=0,last=0,running=true,signals=[];
  const rand=(a,b)=>a+Math.random()*(b-a);
  function resize(){
    const r=layer.getBoundingClientRect(); w=Math.max(1,r.width); h=Math.max(1,r.height);
    dpr=Math.min(window.devicePixelRatio||1,1.35);
    canvas.width=Math.round(w*dpr); canvas.height=Math.round(h*dpr);
    canvas.style.width=w+'px'; canvas.style.height=h+'px'; ctx.setTransform(dpr,0,0,dpr,0,0);
    const count=Math.max(34,Math.min(88,Math.round((w*h)/15500)));
    nodes=Array.from({length:count},()=>({x:rand(-20,w+20),y:rand(-20,h+20),ox:rand(0,w),oy:rand(0,h),vx:rand(-.13,.13),vy:rand(-.10,.10),r:rand(1.1,2.35),phase:rand(0,6.28),tone:Math.random()}));
    signals=Array.from({length:Math.max(7,Math.round(count/8))},()=>({a:Math.floor(rand(0,count)),b:Math.floor(rand(0,count)),t:Math.random(),speed:rand(.0018,.004)}));
  }
  function draw(t){
    if(!running)return; raf=requestAnimationFrame(draw);
    if(t-last<30)return; last=t; ctx.clearRect(0,0,w,h);
    const maxDist=Math.min(210,Math.max(125,w*.17));
    // Connect nodes and add occasional luminous triangle facets.
    for(let i=0;i<nodes.length;i++){
      const a=nodes[i]; a.x+=a.vx; a.y+=a.vy; a.phase+=.012;
      if(a.x < -28)a.x=w+24;if(a.x>w+28)a.x=-24;if(a.y < -28)a.y=h+24;if(a.y>h+28)a.y=-24;
      for(let j=i+1;j<nodes.length;j++){
        const b=nodes[j],dx=a.x-b.x,dy=a.y-b.y,d=Math.hypot(dx,dy);
        if(d<maxDist){
          const k=1-d/maxDist, alpha=.08+k*.24;
          ctx.beginPath();ctx.moveTo(a.x,a.y);ctx.lineTo(b.x,b.y);
          ctx.strokeStyle=(a.tone>.89||b.tone>.89)?`rgba(255,190,222,${alpha*.8})`:`rgba(78,220,246,${alpha})`;
          ctx.lineWidth=.45+k*.7;ctx.stroke();
          if(j%4===0 && d<maxDist*.56){
            ctx.fillStyle=`rgba(57,190,232,${k*.025})`;ctx.beginPath();ctx.moveTo(a.x,a.y);ctx.lineTo(b.x,b.y);
            const c=nodes[(j+3)%nodes.length];ctx.lineTo(c.x,c.y);ctx.closePath();ctx.fill();
          }
        }
      }
      const pulse=.72+.28*Math.sin(a.phase);
      ctx.beginPath();ctx.arc(a.x,a.y,a.r*pulse,0,Math.PI*2);
      ctx.fillStyle=a.tone>.89?'rgba(255,221,239,.95)':'rgba(117,239,255,.95)';ctx.fill();
      ctx.beginPath();ctx.arc(a.x,a.y,5.5*pulse,0,Math.PI*2);
      ctx.fillStyle=a.tone>.89?'rgba(255,174,220,.075)':'rgba(77,218,255,.075)';ctx.fill();
    }
    // Small light signals travel continuously along selected links.
    for(const s of signals){
      const a=nodes[s.a],b=nodes[s.b]; if(!a||!b)continue;
      s.t+=s.speed;if(s.t>1){s.t=0;s.a=Math.floor(rand(0,nodes.length));s.b=Math.floor(rand(0,nodes.length));}
      const x=a.x+(b.x-a.x)*s.t,y=a.y+(b.y-a.y)*s.t;
      const g=ctx.createRadialGradient(x,y,0,x,y,8);g.addColorStop(0,'rgba(255,255,255,.9)');g.addColorStop(.3,'rgba(106,239,255,.45)');g.addColorStop(1,'rgba(106,239,255,0)');
      ctx.fillStyle=g;ctx.beginPath();ctx.arc(x,y,8,0,Math.PI*2);ctx.fill();
    }
  }
  function pause(){running=false;if(raf)cancelAnimationFrame(raf);}
  function resume(){if(running)return;running=true;last=0;raf=requestAnimationFrame(draw);}
  resize();raf=requestAnimationFrame(draw);
  let timer;window.addEventListener('resize',()=>{clearTimeout(timer);timer=setTimeout(resize,160);},{passive:true});
  document.addEventListener('visibilitychange',()=>document.hidden?pause():resume());
})();