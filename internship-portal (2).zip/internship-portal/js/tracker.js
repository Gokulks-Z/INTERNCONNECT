/**
 * Triangular tracker: node focus/selection, reduced-motion handling, and the
 * live activity feed on the home page (polled, paused while the tab is hidden).
 */
(function () {
  'use strict';

  var reducedMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
  var trackers = Array.prototype.slice.call(document.querySelectorAll('.ic-tracker'));

  var nodeInfo = {
    profile: 'Student profile: skills, education and a resume, kept in one place so applying takes a click.',
    opportunity: 'Opportunity: open internships that students can discover, filter and apply to.',
    company: 'Company review: employers read applications and move candidates from Applied to Selected.'
  };

  trackers.forEach(function (tracker) {
    var svg = tracker.querySelector('svg');
    var info = tracker.querySelector('.ic-tracker-info');
    var nodes = Array.prototype.slice.call(tracker.querySelectorAll('.ic-t-node'));
    var defaultText = info ? info.getAttribute('data-default') || '' : '';

    if (reducedMotion && svg && typeof svg.pauseAnimations === 'function') { svg.pauseAnimations(); }

    function setFocus(name) {
      if (name) { tracker.setAttribute('data-focus', name); } else { tracker.removeAttribute('data-focus'); }
    }

    function select(node) {
      var already = node.classList.contains('is-selected');
      nodes.forEach(function (other) { other.classList.remove('is-selected'); });
      if (already) {
        setFocus(null);
        if (info) { info.textContent = defaultText; }
        return;
      }
      node.classList.add('is-selected');
      setFocus(node.getAttribute('data-node'));
      if (info) { info.textContent = nodeInfo[node.getAttribute('data-node')] || defaultText; }
    }

    nodes.forEach(function (node) {
      node.addEventListener('mouseenter', function () { setFocus(node.getAttribute('data-node')); });
      node.addEventListener('mouseleave', function () {
        var selected = tracker.querySelector('.ic-t-node.is-selected');
        setFocus(selected ? selected.getAttribute('data-node') : null);
      });
      node.addEventListener('focus', function () { setFocus(node.getAttribute('data-node')); });
      node.addEventListener('click', function () { select(node); });
      node.addEventListener('keydown', function (event) {
        if (event.key === 'Enter' || event.key === ' ') { event.preventDefault(); select(node); }
      });
    });
  });

  /* ---------------- Live activity feed (home page) ---------------- */
  var feed = document.getElementById('ic-activity-feed');
  if (!feed) { return; }

  var endpoint = feed.getAttribute('data-endpoint');
  var statusNote = document.getElementById('ic-feed-status');
  var liveTracker = document.querySelector('.ic-tracker[data-live="1"]');
  var stateLabels = {
    idle: 'Ready', applied: 'Applied', review: 'Under Review', shortlisted: 'Shortlisted',
    interview: 'Interview', selected: 'Selected', rejected: 'Rejected'
  };
  var timer = null;
  var failures = 0;

  function relativeTime(seconds) {
    if (seconds < 60) { return 'just now'; }
    if (seconds < 3600) { return Math.floor(seconds / 60) + ' min ago'; }
    if (seconds < 86400) { return Math.floor(seconds / 3600) + ' h ago'; }
    return Math.floor(seconds / 86400) + ' d ago';
  }

  function render(data) {
    feed.textContent = '';
    if (!data.events || !data.events.length) {
      var empty = document.createElement('li');
      empty.className = 'ic-feed-empty';
      empty.textContent = 'No activity yet. New internships and application updates will appear here.';
      feed.appendChild(empty);
      return;
    }
    data.events.forEach(function (event) {
      var item = document.createElement('li');
      var text = document.createElement('span');
      text.textContent = event.text;
      var time = document.createElement('span');
      time.className = 'ic-feed-time';
      time.textContent = relativeTime(Math.max(0, data.server_time - event.at));
      item.appendChild(text);
      item.appendChild(time);
      feed.appendChild(item);
    });
  }

  function applyState(state) {
    if (!liveTracker || !stateLabels[state] || liveTracker.getAttribute('data-state') === state) { return; }
    liveTracker.setAttribute('data-state', state);
    var label = liveTracker.querySelector('.ic-t-hub-label');
    if (label) { label.textContent = stateLabels[state]; }
  }

  function poll() {
    if (document.hidden || !endpoint) { return; }
    fetch(endpoint, { headers: { 'Accept': 'application/json' }, credentials: 'same-origin' })
      .then(function (response) { if (!response.ok) { throw new Error('bad status'); } return response.json(); })
      .then(function (data) {
        failures = 0;
        render(data);
        applyState(data.latest_state);
        if (statusNote) { statusNote.textContent = 'Updates automatically'; }
      })
      .catch(function () {
        failures += 1;
        if (statusNote) { statusNote.textContent = 'Activity is temporarily unavailable'; }
        if (failures >= 3) { stop(); }
      });
  }

  function start() { if (timer === null) { poll(); timer = window.setInterval(poll, 30000); } }
  function stop() { if (timer !== null) { window.clearInterval(timer); timer = null; } }

  document.addEventListener('visibilitychange', function () {
    if (document.hidden) { stop(); } else if (failures < 3) { start(); }
  });
  start();
})();
