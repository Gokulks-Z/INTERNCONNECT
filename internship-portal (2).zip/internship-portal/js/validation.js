/**
 * InternConnect — validation.js
 * Client-side validation for register.php and login.php.
 * Server-side validation in the PHP files is the real authority; this is
 * just fast feedback for the user.
 */
(function () {
  "use strict";

  function showError(fieldWrap, message) {
    fieldWrap.classList.add('ic-invalid');
    var err = fieldWrap.querySelector('.ic-error-text');
    if (err) err.textContent = message;
  }
  function clearError(fieldWrap) {
    fieldWrap.classList.remove('ic-invalid');
  }
  function isEmail(value) {
    return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(value);
  }

  /* ---------------- Role toggle on register.php ---------------- */
  var roleInputs = document.querySelectorAll('input[name="role"]');
  var studentFields = document.getElementById('student-fields');
  var companyFields = document.getElementById('company-fields');

  function applyRole() {
    var checked = document.querySelector('input[name="role"]:checked');
    if (!checked) return;
    document.querySelectorAll('.ic-role-option').forEach(function (opt) {
      opt.classList.toggle('active', opt.dataset.role === checked.value);
    });
    if (studentFields && companyFields) {
      var isStudent = checked.value === 'student';
      studentFields.style.display = isStudent ? 'block' : 'none';
      companyFields.style.display = isStudent ? 'none' : 'block';
      studentFields.querySelectorAll('input').forEach(function (i) { i.required = isStudent; });
      companyFields.querySelectorAll('input').forEach(function (i) { i.required = !isStudent; });
    }
  }
  roleInputs.forEach(function (r) { r.addEventListener('change', applyRole); });
  document.querySelectorAll('.ic-role-option').forEach(function (opt) {
    opt.addEventListener('click', function () {
      var input = document.getElementById('role-' + opt.dataset.role);
      if (input) { input.checked = true; applyRole(); }
    });
  });
  if (roleInputs.length) applyRole();

  /* ---------------- Password strength meter ---------------- */
  var pwInput = document.getElementById('password');
  var pwBar = document.getElementById('pw-strength-bar');
  if (pwInput && pwBar) {
    pwInput.addEventListener('input', function () {
      var v = pwInput.value;
      var score = 0;
      if (v.length >= 8) score++;
      if (/[A-Z]/.test(v)) score++;
      if (/[0-9]/.test(v)) score++;
      if (/[^A-Za-z0-9]/.test(v)) score++;
      var pct = (score / 4) * 100;
      pwBar.style.width = pct + '%';
      pwBar.setAttribute('data-level', String(score));
    });
  }

  /* ---------------- Registration form ---------------- */
  var registerForm = document.getElementById('register-form');
  if (registerForm) {
    registerForm.addEventListener('submit', function (e) {
      var valid = true;

      var nameField = document.getElementById('field-name');
      var nameInput = document.getElementById('name');
      if (nameInput && nameInput.value.trim().length < 2) {
        showError(nameField, 'Enter your full name.'); valid = false;
      } else if (nameField) clearError(nameField);

      var emailField = document.getElementById('field-email');
      var emailInput = document.getElementById('email');
      if (emailInput && !isEmail(emailInput.value.trim())) {
        showError(emailField, 'Enter a valid email address.'); valid = false;
      } else if (emailField) clearError(emailField);

      var pwField = document.getElementById('field-password');
      if (pwInput && pwInput.value.length < 12) {
        showError(pwField, 'Use a password or passphrase with at least 12 characters.'); valid = false;
      } else if (pwField) clearError(pwField);

      var confirmField = document.getElementById('field-confirm');
      var confirmInput = document.getElementById('confirm_password');
      if (confirmInput && pwInput && confirmInput.value !== pwInput.value) {
        showError(confirmField, 'Passwords do not match.'); valid = false;
      } else if (confirmField) clearError(confirmField);

      if (!valid) e.preventDefault();
    });
  }

  /* ---------------- Reset-password form ---------------- */
  var resetForm = document.getElementById('reset-form');
  if (resetForm) {
    resetForm.addEventListener('submit', function (e) {
      var valid = true;
      var pwField = document.getElementById('field-password');
      if (pwInput && pwInput.value.length < 12) {
        showError(pwField, 'Use a password or passphrase with at least 12 characters.'); valid = false;
      } else if (pwField) clearError(pwField);

      var confirmField = document.getElementById('field-confirm');
      var confirmInput = document.getElementById('confirm_password');
      if (confirmInput && pwInput && confirmInput.value !== pwInput.value) {
        showError(confirmField, 'Passwords do not match.'); valid = false;
      } else if (confirmField) clearError(confirmField);

      if (!valid) e.preventDefault();
    });
  }

  /* ---------------- Login form ---------------- */
  var loginForm = document.getElementById('login-form');
  if (loginForm) {
    loginForm.addEventListener('submit', function (e) {
      var valid = true;
      var emailField = document.getElementById('field-email');
      var emailInput = document.getElementById('email');
      if (emailInput && !isEmail(emailInput.value.trim())) {
        showError(emailField, 'Enter a valid email address.'); valid = false;
      } else if (emailField) clearError(emailField);

      var pwField = document.getElementById('field-password');
      var pwInputLogin = document.getElementById('password');
      if (pwInputLogin && pwInputLogin.value.length === 0) {
        showError(pwField, 'Enter your password.'); valid = false;
      } else if (pwField) clearError(pwField);

      if (!valid) e.preventDefault();
    });
  }

  /* ---------------- Resume upload: quick client-side check ---------------- */
  var resumeInput = document.getElementById('resume');
  if (resumeInput) {
    resumeInput.addEventListener('change', function () {
      var field = document.getElementById('field-resume');
      var file = resumeInput.files[0];
      if (!file) return;
      var okType = /\.(pdf|doc|docx)$/i.test(file.name);
      var okSize = file.size <= 2 * 1024 * 1024;
      if (!okType) { showError(field, 'Upload a PDF, DOC or DOCX file.'); resumeInput.value = ''; }
      else if (!okSize) { showError(field, 'File must be 2MB or smaller.'); resumeInput.value = ''; }
      else clearError(field);
    });
  }
})();
