<?php
require_once __DIR__ . '/includes/auth.php';

redirect_if_logged_in();

$errors = [];
$oldEmail = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!csrf_verify($_POST['csrf_token'] ?? '')) {
        $errors[] = 'Your session expired. Please try submitting the form again.';
    }

    $oldEmail = strtolower(trim((string) ($_POST['email'] ?? '')));
    $password = (string) ($_POST['password'] ?? '');

    if (!filter_var($oldEmail, FILTER_VALIDATE_EMAIL)) {
        $errors[] = 'Enter a valid email address.';
    }
    if ($password === '') {
        $errors[] = 'Enter your password.';
    }

    $bucket = 'login:' . $oldEmail;
    if (!$errors && !throttle_allowed($bucket, 5, 600)) {
        $errors[] = 'Too many attempts for this email. Please wait a few minutes and try again.';
    }

    if (!$errors) {
        $pdo = getDBConnection();
        $stmt = $pdo->prepare('SELECT id, full_name, password, role FROM users WHERE email = ? LIMIT 1');
        $stmt->execute([$oldEmail]);
        $user = $stmt->fetch();

        // Unknown emails still pay for one password hash, so response time
        // does not reveal whether the account exists.
        if ($user) {
            $passwordOk = password_verify($password, $user['password']);
        } else {
            password_hash($password, PASSWORD_DEFAULT);
            $passwordOk = false;
        }

        if (!$user || !$passwordOk) {
            throttle_hit($bucket);
            $errors[] = 'Email or password is incorrect. Please check your details and try again.';
        } else {
            throttle_clear($bucket);
            session_regenerate_id(true);
            $_SESSION['user_id'] = (int) $user['id'];
            $_SESSION['role']    = $user['role'];
            $_SESSION['name']    = $user['full_name'];

            set_flash('success', 'Welcome back, ' . $user['full_name'] . '.');
            redirect($user['role'] === 'student' ? 'student/dashboard.php' : 'company/dashboard.php');
        }
    }
}

$page_title = 'Log in';
require __DIR__ . '/includes/header.php';
?>

<div class="ic-auth">
  <aside class="ic-auth-side ic-dark">
    <p class="ic-auth-kicker">InternConnect</p>
    <h2>Pick up where you left off.</h2>
    <p>Your applications, their stages, and the next thing to do, in one place.</p>
    <div class="ic-auth-tracker" aria-hidden="true">
      <?php $trackerState = 'idle'; $trackerCompact = true; include __DIR__ . '/includes/tracker.php'; ?>
    </div>
  </aside>

  <div class="ic-auth-main">
    <div class="ic-panel ic-panel-narrow<?= $errors ? ' ic-panel-shake' : '' ?>">
      <h1 class="ic-auth-title">Welcome back</h1>
      <p>Log in to your account.</p>

      <?php if ($errors): ?>
        <div class="ic-flash ic-flash-error" role="alert">
          <?php foreach ($errors as $error): ?><div><?= clean($error) ?></div><?php endforeach; ?>
        </div>
      <?php endif; ?>

      <form id="login-form" method="POST" action="login.php" novalidate>
        <?= csrf_field() ?>

        <div class="ic-field" id="field-email">
          <label for="email">Email</label>
          <input type="email" id="email" name="email" value="<?= clean($oldEmail) ?>" required autocomplete="email" <?= $errors ? '' : 'autofocus' ?>>
          <div class="ic-error-text">Enter a valid email address.</div>
        </div>

        <div class="ic-field<?= $errors ? ' ic-field-reset' : '' ?>" id="field-password">
          <div class="ic-field-head">
            <label for="password">Password</label>
            <a href="forgot-password.php" class="ic-field-link">Forgot password?</a>
          </div>
          <div class="ic-password-wrap">
            <input type="password" id="password" name="password" required autocomplete="current-password" <?= $errors ? 'autofocus' : '' ?>>
            <button type="button" class="ic-pw-toggle" aria-label="Show password"></button>
          </div>
          <div class="ic-error-text">Enter your password.</div>
        </div>

        <button type="submit" class="ic-btn ic-btn-primary ic-btn-block" data-loading-text="Signing in…">Log in</button>
      </form>

      <p class="ic-auth-foot">New to InternConnect? <a href="register.php">Create an account</a></p>
    </div>
  </div>
</div>

<?php require __DIR__ . '/includes/footer.php'; ?>
