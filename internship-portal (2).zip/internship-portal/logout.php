<?php
require_once __DIR__ . '/includes/auth.php';

// Reuses the session started by the bootstrap: empty it, issue a new id, and
// leave a confirmation message for the next page.
$_SESSION = [];
session_regenerate_id(true);
set_flash('success', 'You have been logged out.');
redirect('index.php');
