<?php
require_once __DIR__ . '/includes/auth.php';

redirect_if_logged_in();

$errors = [];
$old = [
    'full_name'     => '',
    'email'         => '',
    'role'          => (($_GET['role'] ?? '') === 'company') ? 'company' : 'student',
    'college'       => '',
    'department'    => '',
    'year_of_study' => '',
    'company_name'  => '',
    'industry'      => '',
    'website'       => '',
];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $old['full_name']     = trim((string) ($_POST['name'] ?? ''));
    $old['email']         = strtolower(trim((string) ($_POST['email'] ?? '')));
    $old['role']          = (($_POST['role'] ?? '') === 'company') ? 'company' : 'student';
    $old['college']       = trim((string) ($_POST['college'] ?? ''));
    $old['department']    = trim((string) ($_POST['department'] ?? ''));
    $old['year_of_study'] = trim((string) ($_POST['year_of_study'] ?? ''));
    $old['company_name']  = trim((string) ($_POST['company_name'] ?? ''));
    $old['industry']      = trim((string) ($_POST['industry'] ?? ''));
    $old['website']       = trim((string) ($_POST['website'] ?? ''));

    $password = (string) ($_POST['password'] ?? '');
    $confirm  = (string) ($_POST['confirm_password'] ?? '');

    if (!csrf_verify($_POST['csrf_token'] ?? '')) {
        $errors[] = 'Your session expired. Please refresh the page and try again.';
    }

    $nameLength = safe_strlen($old['full_name']);
    if ($nameLength < 2) {
        $errors[] = 'Enter your full name.';
    } elseif ($nameLength > 100) {
        $errors[] = 'Full name must be 100 characters or fewer.';
    }

    if (!filter_var($old['email'], FILTER_VALIDATE_EMAIL)) {
        $errors[] = 'Enter a valid email address.';
    } elseif (safe_strlen($old['email']) > 150) {
        $errors[] = 'Email address must be 150 characters or fewer.';
    }

    if (safe_strlen($password) < 12) {
        $errors[] = 'Use a password or passphrase with at least 12 characters.';
    }
    if ($password !== $confirm) {
        $errors[] = 'Passwords do not match.';
    }

    if ($old['role'] === 'company' && safe_strlen($old['company_name']) < 2) {
        $errors[] = 'Enter your company name.';
    }

    $limits = [
        'college' => [150, 'College name'], 'department' => [100, 'Department'],
        'year_of_study' => [20, 'Year of study'], 'company_name' => [150, 'Company name'],
        'industry' => [100, 'Industry'], 'website' => [255, 'Website'],
    ];
    foreach ($limits as $field => [$max, $label]) {
        if (safe_strlen($old[$field]) > $max) {
            $errors[] = $label . ' must be ' . $max . ' characters or fewer.';
        }
    }

    if ($old['website'] !== '' && !filter_var($old['website'], FILTER_VALIDATE_URL)) {
        $errors[] = 'Enter a valid website address, for example https://example.com.';
    }
    if ($old['website'] !== '' && !preg_match('#^https?://#i', $old['website'])) {
        $errors[] = 'The website address must start with http:// or https://.';
    }

    if (!$errors) {
        $pdo = getDBConnection();

        $check = $pdo->prepare('SELECT id FROM users WHERE email = ? LIMIT 1');
        $check->execute([$old['email']]);
        if ($check->fetch()) {
            $errors[] = 'An account with that email already exists. Try logging in instead.';
        }
    }

    if (!$errors) {
        try {
            $pdo->beginTransaction();

            $pdo->prepare('INSERT INTO users (full_name, email, password, role) VALUES (?, ?, ?, ?)')
                ->execute([$old['full_name'], $old['email'], password_hash($password, PASSWORD_DEFAULT), $old['role']]);
            $userId = (int) $pdo->lastInsertId();

            if ($old['role'] === 'student') {
                $pdo->prepare('INSERT INTO students (user_id, college, department, year_of_study) VALUES (?, ?, ?, ?)')
                    ->execute([
                        $userId,
                        $old['college'] !== '' ? $old['college'] : null,
                        $old['department'] !== '' ? $old['department'] : null,
                        $old['year_of_study'] !== '' ? $old['year_of_study'] : null,
                    ]);
            } else {
                $pdo->prepare('INSERT INTO companies (user_id, company_name, industry, website) VALUES (?, ?, ?, ?)')
                    ->execute([
                        $userId,
                        $old['company_name'],
                        $old['industry'] !== '' ? $old['industry'] : null,
                        $old['website'] !== '' ? $old['website'] : null,
                    ]);
            }

            $pdo->commit();

            session_regenerate_id(true);
            $_SESSION['user_id'] = $userId;
            $_SESSION['role']    = $old['role'];
            $_SESSION['name']    = $old['full_name'];

            set_flash('success', 'Welcome to InternConnect, ' . $old['full_name'] . '.');
            redirect($old['role'] === 'student' ? 'student/dashboard.php' : 'company/dashboard.php');
        } catch (PDOException $e) {
            if ($pdo->inTransaction()) {
                $pdo->rollBack();
            }
            error_log('InternConnect: registration failed (code ' . $e->getCode() . ').');
            $errors[] = ((string) $e->getCode() === '23000')
                ? 'An account with that email already exists. Try logging in instead.'
                : 'We could not create your account right now. Please try again.';
        }
    }
}

$page_title = 'Create your account';
require __DIR__ . '/includes/header.php';
?>

<section class="ic-register-hero-tag ic-dark" aria-label="InternConnect introduction">
  <div class="ic-container ic-register-hero-inner">
    <p class="ic-eyebrow"><span class="ic-eyebrow-dot" aria-hidden="true"></span>YOUR NEXT CHAPTER STARTS HERE</p>
    <h1>Make your next move. <span>Make it count.</span></h1>
    <p class="ic-register-hero-lead">Create your InternConnect account to build your profile, discover opportunities, and follow your progress from application to outcome.</p>
  </div>
</section>

<div class="ic-auth">
  <aside class="ic-auth-side ic-dark">
    <p class="ic-auth-kicker">Join InternConnect</p>
    <h2>Discover. Apply. Track. Launch.</h2>
    <p>Students build one profile and apply in a click. Companies post roles and move applicants forward stage by stage.</p>
    <ol class="ic-auth-steps" aria-hidden="true">
      <li>Create your profile</li>
      <li>Find a role that fits</li>
      <li>Watch your application progress</li>
    </ol>
  </aside>

  <div class="ic-auth-main">
    <div class="ic-panel ic-panel-narrow">
      <h1 class="ic-auth-title">Create your account</h1>
      <p>Join as a student looking for roles, or as a company posting them.</p>

      <?php if ($errors): ?>
        <div class="ic-flash ic-flash-error" role="alert">
          <?php foreach ($errors as $error): ?><div><?= clean($error) ?></div><?php endforeach; ?>
        </div>
      <?php endif; ?>

      <form id="register-form" method="POST" action="register.php" novalidate>
        <?= csrf_field() ?>

        <div class="ic-role-toggle" role="radiogroup" aria-label="Account type">
          <label class="ic-role-option" data-role="student">
            <input type="radio" id="role-student" name="role" value="student" <?= $old['role'] === 'student' ? 'checked' : '' ?>>
            I'm a student
          </label>
          <label class="ic-role-option" data-role="company">
            <input type="radio" id="role-company" name="role" value="company" <?= $old['role'] === 'company' ? 'checked' : '' ?>>
            I'm hiring
          </label>
        </div>

        <div class="ic-field" id="field-name">
          <label for="name">Full name</label>
          <input type="text" id="name" name="name" value="<?= clean($old['full_name']) ?>" required maxlength="100" autocomplete="name">
          <div class="ic-error-text">Enter your full name.</div>
        </div>

        <div class="ic-field" id="field-email">
          <label for="email">Email</label>
          <input type="email" id="email" name="email" value="<?= clean($old['email']) ?>" required maxlength="150" autocomplete="email">
          <div class="ic-error-text">Enter a valid email address.</div>
        </div>

        <div id="student-fields"<?= $old['role'] === 'company' ? ' hidden' : '' ?>>
          <div class="ic-field">
            <label for="college">College</label>
            <input type="text" id="college" name="college" value="<?= clean($old['college']) ?>" maxlength="150">
          </div>
          <div class="ic-field-pair">
            <div class="ic-field">
              <label for="department">Department</label>
              <input type="text" id="department" name="department" value="<?= clean($old['department']) ?>" maxlength="100" placeholder="Computer Science">
            </div>
            <div class="ic-field">
              <label for="year_of_study">Year</label>
              <input type="text" id="year_of_study" name="year_of_study" value="<?= clean($old['year_of_study']) ?>" maxlength="20" placeholder="3rd year">
            </div>
          </div>
        </div>

        <div id="company-fields"<?= $old['role'] === 'student' ? ' hidden' : '' ?>>
          <div class="ic-field">
            <label for="company_name">Company name</label>
            <input type="text" id="company_name" name="company_name" value="<?= clean($old['company_name']) ?>" maxlength="150">
          </div>
          <div class="ic-field-pair">
            <div class="ic-field">
              <label for="industry">Industry</label>
              <input type="text" id="industry" name="industry" value="<?= clean($old['industry']) ?>" maxlength="100" placeholder="Fintech">
            </div>
            <div class="ic-field">
              <label for="website">Website</label>
              <input type="url" id="website" name="website" value="<?= clean($old['website']) ?>" maxlength="255" placeholder="https://">
            </div>
          </div>
        </div>

        <div class="ic-field" id="field-password">
          <label for="password">Password</label>
          <div class="ic-password-wrap">
            <input type="password" id="password" name="password" required minlength="12" autocomplete="new-password">
            <button type="button" class="ic-pw-toggle" aria-label="Show password"></button>
          </div>
          <div class="ic-pw-strength"><div class="ic-pw-strength-bar" id="pw-strength-bar"></div></div>
          <div class="ic-hint">Use 12+ characters; a unique passphrase is easier to remember and harder to guess.</div>
          <div class="ic-error-text">Use a password or passphrase with at least 12 characters.</div>
        </div>

        <div class="ic-field" id="field-confirm">
          <label for="confirm_password">Confirm password</label>
          <div class="ic-password-wrap">
            <input type="password" id="confirm_password" name="confirm_password" required autocomplete="new-password">
            <button type="button" class="ic-pw-toggle" aria-label="Show password"></button>
          </div>
          <div class="ic-error-text">Passwords do not match.</div>
        </div>

        <button type="submit" class="ic-btn ic-btn-primary ic-btn-block" data-loading-text="Creating account…">Create account</button>
      </form>

      <p class="ic-auth-foot">Already have an account? <a href="login.php">Log in</a></p>
    </div>
  </div>
</div>

<?php require __DIR__ . '/includes/footer.php'; ?>
