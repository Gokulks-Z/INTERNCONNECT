<?php
require_once __DIR__ . '/includes/auth.php';
require_once __DIR__ . '/includes/schema.php';

redirect_if_logged_in();

$token = (string) ($_GET['token'] ?? ($_POST['token'] ?? ''));
if (!preg_match('/^[a-f0-9]{64}$/', $token)) {
    $token = '';
}

$errors = [];
$validToken = false;
$userId = 0;
$tokenHash = $token !== '' ? hash('sha256', $token) : '';

$pdo = getDBConnection();
ensure_aux_tables($pdo);

if ($tokenHash !== '') {
    $stmt = $pdo->prepare('SELECT user_id, expires_at, used FROM password_resets WHERE token_hash = ? LIMIT 1');
    $stmt->execute([$tokenHash]);
    $row = $stmt->fetch();

    if ($row && !(int) $row['used'] && strtotime($row['expires_at'] . ' UTC') > time()) {
        $validToken = true;
        $userId = (int) $row['user_id'];
    }
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!csrf_verify($_POST['csrf_token'] ?? '')) {
        $errors[] = 'Your session expired. Please try again.';
    }
    if (!$validToken) {
        $errors[] = 'This reset link is invalid or has expired. Please request a new one.';
    }

    $password = (string) ($_POST['password'] ?? '');
    $confirm = (string) ($_POST['confirm_password'] ?? '');
    if (safe_strlen($password) < 12) {
        $errors[] = 'Use a password or passphrase with at least 12 characters.';
    }
    if ($password !== $confirm) {
        $errors[] = 'Passwords do not match.';
    }

    if (!$errors) {
        try {
            $pdo->beginTransaction();
            $pdo->prepare('UPDATE users SET password = ? WHERE id = ?')
                ->execute([password_hash($password, PASSWORD_DEFAULT), $userId]);
            $pdo->prepare('UPDATE password_resets SET used = 1 WHERE user_id = ? AND used = 0')
                ->execute([$userId]);
            $pdo->commit();

            set_flash('success', 'Password updated. Log in with your new password.');
            redirect('login.php');
        } catch (PDOException $e) {
            if ($pdo->inTransaction()) {
                $pdo->rollBack();
            }
            error_log('InternConnect: password reset failed (code ' . $e->getCode() . ').');
            $errors[] = 'We could not update your password. Please try again.';
        }
    }
}

$page_title = 'Choose a new password';
require __DIR__ . '/includes/header.php';
?>

<div class="ic-auth">
  <aside class="ic-auth-side ic-dark" aria-hidden="true">
    <p class="ic-auth-kicker">Account recovery</p>
    <h2>A fresh start.</h2>
    <p>Pick something you have not used elsewhere.</p>
  </aside>

  <div class="ic-auth-main">
    <div class="ic-panel ic-panel-narrow">
      <?php if (!$validToken): ?>
        <h1 class="ic-auth-title">Link invalid or expired</h1>
        <p>Reset links work once and expire after an hour.</p>
        <a href="forgot-password.php" class="ic-btn ic-btn-primary ic-btn-block">Request a new link</a>
      <?php else: ?>
        <h1 class="ic-auth-title">Choose a new password</h1>
        <p>Use at least 12 characters.</p>

        <?php if ($errors): ?>
          <div class="ic-flash ic-flash-error" role="alert">
            <?php foreach ($errors as $error): ?><div><?= clean($error) ?></div><?php endforeach; ?>
          </div>
        <?php endif; ?>

        <form id="reset-form" method="POST" action="reset-password.php" novalidate>
          <?= csrf_field() ?>
          <input type="hidden" name="token" value="<?= clean($token) ?>">

          <div class="ic-field" id="field-password">
            <label for="password">New password</label>
            <div class="ic-password-wrap">
              <input type="password" id="password" name="password" required minlength="12" autofocus autocomplete="new-password">
              <button type="button" class="ic-pw-toggle" aria-label="Show password"></button>
            </div>
            <div class="ic-pw-strength"><div class="ic-pw-strength-bar" id="pw-strength-bar"></div></div>
            <div class="ic-error-text">Use a password or passphrase with at least 12 characters.</div>
          </div>

          <div class="ic-field" id="field-confirm">
            <label for="confirm_password">Confirm new password</label>
            <div class="ic-password-wrap">
              <input type="password" id="confirm_password" name="confirm_password" required autocomplete="new-password">
              <button type="button" class="ic-pw-toggle" aria-label="Show password"></button>
            </div>
            <div class="ic-error-text">Passwords do not match.</div>
          </div>

          <button type="submit" class="ic-btn ic-btn-primary ic-btn-block" data-loading-text="Updating…">Set new password</button>
        </form>
      <?php endif; ?>
    </div>
  </div>
</div>

<?php require __DIR__ . '/includes/footer.php'; ?>
