<?php
/**
 * Authorised resume download. A student may fetch their own file; a company
 * may fetch it only if that student applied to one of the company's postings.
 */
require_once __DIR__ . '/includes/auth.php';

function resume_denied(int $status): void
{
    http_response_code($status);
    header('Content-Type: text/plain; charset=utf-8');
    echo $status === 404 ? 'Resume not found.' : 'You do not have access to this file.';
    exit;
}

if (!is_logged_in()) {
    resume_denied(403);
}

$studentId = (int) ($_GET['student'] ?? 0);
if ($studentId <= 0) {
    resume_denied(404);
}

$pdo = getDBConnection();
$stmt = $pdo->prepare('SELECT id, user_id, resume_path FROM students WHERE id = ? LIMIT 1');
$stmt->execute([$studentId]);
$student = $stmt->fetch();

if (!$student || empty($student['resume_path'])) {
    resume_denied(404);
}

$allowed = false;
if (current_role() === 'student') {
    $allowed = (int) $student['user_id'] === current_user_id();
} elseif (current_role() === 'company') {
    $check = $pdo->prepare(
        'SELECT 1 FROM applications a
         JOIN internships i ON i.id = a.internship_id
         JOIN companies c ON c.id = i.company_id
         WHERE a.student_id = ? AND c.user_id = ? LIMIT 1'
    );
    $check->execute([$student['id'], current_user_id()]);
    $allowed = (bool) $check->fetchColumn();
}

if (!$allowed) {
    resume_denied(403);
}

$name = basename((string) $student['resume_path']);
if (!preg_match('/^[A-Za-z0-9_.-]+$/', $name)) {
    resume_denied(404);
}

$path = null;
foreach ([storage_path('resumes') . '/' . $name, project_root() . '/uploads/resumes/' . $name] as $candidate) {
    if (is_file($candidate)) {
        $path = $candidate;
        break;
    }
}
if ($path === null) {
    resume_denied(404);
}

$types = [
    'pdf'  => 'application/pdf',
    'doc'  => 'application/msword',
    'docx' => 'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
];
$extension = strtolower(pathinfo($name, PATHINFO_EXTENSION));
if (!isset($types[$extension])) {
    resume_denied(404);
}

header('Content-Type: ' . $types[$extension]);
header('Content-Length: ' . filesize($path));
header('Content-Disposition: ' . ($extension === 'pdf' ? 'inline' : 'attachment') . '; filename="resume-' . $student['id'] . '.' . $extension . '"');
header('Cache-Control: private, no-store');
readfile($path);
exit;
