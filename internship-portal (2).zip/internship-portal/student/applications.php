<?php
require_once __DIR__ . '/../includes/auth.php';
require_role('student');

const APPLICATION_STAGES = ['Applied', 'Under Review', 'Shortlisted', 'Interview', 'Selected'];

$pdo = getDBConnection();
$student = get_student_profile($pdo, current_user_id());

$applications = [];
if ($student) {
    $stmt = $pdo->prepare(
        'SELECT a.id, a.status, a.applied_at, a.updated_at, i.id AS internship_id, i.title, i.location, i.work_mode, c.company_name
         FROM applications a
         JOIN internships i ON i.id = a.internship_id
         JOIN companies c ON c.id = i.company_id
         WHERE a.student_id = ?
         ORDER BY a.updated_at DESC'
    );
    $stmt->execute([$student['id']]);
    $applications = $stmt->fetchAll();
}

/** Stage list for one application; the status always comes from the database. */
function render_timeline(string $status): string
{
    $html = '<ol class="ic-timeline" aria-label="Application progress">';

    if ($status === 'Rejected') {
        $html .= '<li class="ic-tl-step is-done"><span class="ic-tl-node">&#10003;</span><span class="ic-tl-label">Applied</span></li>';
        $html .= '<li class="ic-tl-bar is-done" aria-hidden="true"></li>';
        $html .= '<li class="ic-tl-step is-rejected is-current" aria-current="step"><span class="ic-tl-node">&times;</span><span class="ic-tl-label">Rejected</span></li>';
        return $html . '</ol>';
    }

    $current = array_search($status, APPLICATION_STAGES, true);
    foreach (APPLICATION_STAGES as $index => $label) {
        $classes = 'ic-tl-step';
        if ($current !== false && $index < $current) {
            $classes .= ' is-done';
        } elseif ($index === $current) {
            $classes .= ' is-current' . ($status === 'Selected' ? ' is-selected' : '');
        }
        $symbol = ($current !== false && $index <= $current && $index !== $current) || $status === 'Selected' && $index === $current
            ? '&#10003;' : (string) ($index + 1);

        $html .= '<li class="' . $classes . '"' . ($index === $current ? ' aria-current="step"' : '') . '>'
            . '<span class="ic-tl-node">' . $symbol . '</span>'
            . '<span class="ic-tl-label">' . clean($label) . '</span></li>';
        if ($index < count(APPLICATION_STAGES) - 1) {
            $html .= '<li class="ic-tl-bar' . ($current !== false && $index < $current ? ' is-done' : '') . '" aria-hidden="true"></li>';
        }
    }
    return $html . '</ol>';
}

$page_title = 'Applications';
require __DIR__ . '/../includes/header.php';
?>

<div class="ic-container ic-section">
  <header class="ic-page-head">
    <div>
      <p class="ic-eyebrow">Applications</p>
      <h1>Every application and where it stands.</h1>
    </div>
  </header>

  <?php if ($applications): ?>
    <div class="ic-listing">
      <?php foreach ($applications as $application): ?>
        <article class="ic-panel ic-application">
          <div class="ic-application-head">
            <div>
              <h2><a href="internship_details.php?id=<?= (int) $application['internship_id'] ?>"><?= clean($application['title']) ?></a></h2>
              <p><?= clean($application['company_name']) ?> · <?= clean($application['location'] ?: $application['work_mode']) ?></p>
            </div>
            <span class="ic-badge badge-<?= clean(str_replace(' ', '-', $application['status'])) ?>"><?= clean($application['status']) ?></span>
          </div>
          <?= render_timeline($application['status']) ?>
          <p class="ic-application-dates">
            Applied <?= clean(date('d M Y', strtotime($application['applied_at']))) ?>
            · Last update <?= clean(date('d M Y, H:i', strtotime($application['updated_at']))) ?>
          </p>
        </article>
      <?php endforeach; ?>
    </div>
  <?php else: ?>
    <div class="ic-empty ic-panel">
      <h2>No applications yet</h2>
      <p>Your next opportunity starts here.</p>
      <a href="internships.php" class="ic-btn ic-btn-primary">Browse internships</a>
    </div>
  <?php endif; ?>
</div>

<?php require __DIR__ . '/../includes/footer.php'; ?>
