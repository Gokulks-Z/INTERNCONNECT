<?php
require_once __DIR__ . '/../includes/auth.php';
require_role('student');

if ($_SERVER['REQUEST_METHOD'] !== 'POST' || !csrf_verify($_POST['csrf_token'] ?? '')) {
    redirect('student/internships.php');
}

$pdo = getDBConnection();
$student = get_student_profile($pdo, current_user_id());
$internshipId = (int) ($_POST['internship_id'] ?? 0);
$returnTo = ($_POST['return'] ?? '') === 'details' && $internshipId > 0
    ? 'student/internship_details.php?id=' . $internshipId
    : 'student/internships.php';

if (!$student) {
    set_flash('error', 'Please complete your profile before applying.');
    redirect('student/profile.php');
}

$stmt = $pdo->prepare("SELECT id FROM internships WHERE id = ? AND status = 'Open' LIMIT 1");
$stmt->execute([$internshipId]);
if (!$stmt->fetch()) {
    set_flash('error', 'That internship is no longer accepting applications.');
    redirect('student/internships.php');
}

try {
    $pdo->prepare("INSERT INTO applications (student_id, internship_id, status) VALUES (?, ?, 'Applied')")
        ->execute([$student['id'], $internshipId]);
    set_flash('success', 'Application submitted. Follow its progress under Applications.');
} catch (PDOException $e) {
    // The unique key on (student_id, internship_id) blocks duplicates.
    set_flash('error', 'You have already applied to this internship.');
}

redirect($returnTo);
