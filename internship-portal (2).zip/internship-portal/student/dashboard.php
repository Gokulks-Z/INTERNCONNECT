<?php
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/tracker_state.php';
require_role('student');

$pdo = getDBConnection();
$student = get_student_profile($pdo, current_user_id());
$studentId = $student ? (int) $student['id'] : 0;

$stats = ['total' => 0, 'progress' => 0, 'shortlisted' => 0, 'selected' => 0];
$statusCounts = [];
$recent = [];
$available = [];

if ($studentId) {
    $stmt = $pdo->prepare('SELECT status, COUNT(*) AS c FROM applications WHERE student_id = ? GROUP BY status');
    $stmt->execute([$studentId]);
    foreach ($stmt->fetchAll() as $row) {
        $statusCounts[$row['status']] = (int) $row['c'];
        $stats['total'] += (int) $row['c'];
    }
    $stats['progress']    = ($statusCounts['Applied'] ?? 0) + ($statusCounts['Under Review'] ?? 0) + ($statusCounts['Interview'] ?? 0);
    $stats['shortlisted'] = $statusCounts['Shortlisted'] ?? 0;
    $stats['selected']    = $statusCounts['Selected'] ?? 0;

    $stmt = $pdo->prepare(
        'SELECT a.status, a.applied_at, a.updated_at, i.id AS internship_id, i.title, c.company_name
         FROM applications a
         JOIN internships i ON i.id = a.internship_id
         JOIN companies c ON c.id = i.company_id
         WHERE a.student_id = ?
         ORDER BY a.updated_at DESC LIMIT 5'
    );
    $stmt->execute([$studentId]);
    $recent = $stmt->fetchAll();
}

$stmt = $pdo->prepare(
    "SELECT i.id, i.title, i.location, i.work_mode, i.stipend, i.duration, c.company_name
     FROM internships i
     JOIN companies c ON c.id = i.company_id
     WHERE i.status = 'Open'
       AND NOT EXISTS (SELECT 1 FROM applications a WHERE a.internship_id = i.id AND a.student_id = ?)
     ORDER BY i.posted_at DESC LIMIT 4"
);
$stmt->execute([$studentId]);
$available = $stmt->fetchAll();

$completion = student_completion($student);
$latest = $recent[0] ?? null;

$trackerState = tracker_state_from_status($latest['status'] ?? null);
$trackerLive = false;
$trackerCaption = $latest
    ? 'Latest: ' . $latest['status'] . ' for ' . $latest['title'] . ' at ' . $latest['company_name'] . '.'
    : 'Apply to an internship and this tracker starts moving.';

if ($completion['percent'] < 100) {
    $next = ['Finish your profile', 'Add your ' . $completion['missing'][0] . ' so companies see a complete picture.', 'student/profile.php', 'Open profile'];
} elseif (!$stats['total']) {
    $next = ['Find your first internship', 'Browse open roles and apply in one click.', 'student/internships.php', 'Browse internships'];
} elseif (!empty($statusCounts['Interview'])) {
    $next = ['You have an interview stage', 'Review the role details and get ready.', 'student/applications.php', 'View applications'];
} else {
    $next = ['Keep an eye on your applications', 'Companies update stages as they review.', 'student/applications.php', 'View applications'];
}

$page_title = 'Dashboard';
require __DIR__ . '/../includes/header.php';
?>

<div class="ic-container ic-section">
  <header class="ic-page-head">
    <div>
      <p class="ic-eyebrow">Student workspace</p>
      <h1>Hi <?= clean(explode(' ', trim((string) $_SESSION['name']))[0]) ?>, here is where you stand.</h1>
    </div>
    <div class="ic-completion" aria-label="Profile completion">
      <div class="ic-completion-top"><strong><?= (int) $completion['percent'] ?>%</strong><span>profile complete</span></div>
      <div class="ic-meter"><span style="width:<?= (int) $completion['percent'] ?>%"></span></div>
    </div>
  </header>

  <div class="ic-dash-grid">
    <section class="ic-panel ic-dash-tracker ic-dark" aria-labelledby="tracker-title">
      <h2 id="tracker-title">Application tracker</h2>
      <?php include __DIR__ . '/../includes/tracker.php'; ?>
    </section>

    <div class="ic-dash-side">
      <section class="ic-panel ic-next">
        <p class="ic-eyebrow">Next step</p>
        <h2><?= clean($next[0]) ?></h2>
        <p><?= clean($next[1]) ?></p>
        <a class="ic-btn ic-btn-primary" href="<?= clean(url($next[2])) ?>"><?= clean($next[3]) ?></a>
      </section>

      <div class="ic-stats-grid">
        <div class="ic-stat"><b><?= $stats['total'] ?></b><span>Applications</span></div>
        <div class="ic-stat"><b><?= $stats['progress'] ?></b><span>In progress</span></div>
        <div class="ic-stat"><b><?= $stats['shortlisted'] ?></b><span>Shortlisted</span></div>
        <div class="ic-stat"><b><?= $stats['selected'] ?></b><span>Selected</span></div>
      </div>
    </div>
  </div>

  <section class="ic-block">
    <div class="ic-block-head">
      <h2>Recent applications</h2>
      <a class="ic-btn ic-btn-ghost ic-btn-sm" href="applications.php">All applications</a>
    </div>
    <?php if ($recent): ?>
      <ul class="ic-activity-list">
        <?php foreach ($recent as $row): ?>
          <li>
            <div>
              <strong><?= clean($row['title']) ?></strong>
              <span><?= clean($row['company_name']) ?> · updated <?= clean(date('d M Y', strtotime($row['updated_at']))) ?></span>
            </div>
            <span class="ic-badge badge-<?= clean(str_replace(' ', '-', $row['status'])) ?>"><?= clean($row['status']) ?></span>
          </li>
        <?php endforeach; ?>
      </ul>
    <?php else: ?>
      <div class="ic-empty"><p>No applications yet. Your next opportunity starts with one click.</p></div>
    <?php endif; ?>
  </section>

  <section class="ic-block">
    <div class="ic-block-head">
      <h2>Open internships</h2>
      <a class="ic-btn ic-btn-ghost ic-btn-sm" href="internships.php">Browse all</a>
    </div>
    <?php if ($available): ?>
      <div class="ic-card-grid">
        <?php foreach ($available as $item): ?>
          <a class="ic-mini-card" href="internship_details.php?id=<?= (int) $item['id'] ?>">
            <strong><?= clean($item['title']) ?></strong>
            <span><?= clean($item['company_name']) ?></span>
            <small><?= clean($item['location'] ?: $item['work_mode']) ?><?= $item['stipend'] ? ' · ' . clean($item['stipend']) : '' ?></small>
          </a>
        <?php endforeach; ?>
      </div>
    <?php else: ?>
      <div class="ic-empty"><p>No open internships you have not applied to yet. Check back soon.</p></div>
    <?php endif; ?>
  </section>
</div>

<?php require __DIR__ . '/../includes/footer.php'; ?>
