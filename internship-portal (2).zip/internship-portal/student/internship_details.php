<?php
require_once __DIR__ . '/../includes/auth.php';
require_role('student');

$pdo = getDBConnection();
$student = get_student_profile($pdo, current_user_id());

$internship_id = isset($_GET['id']) ? (int) $_GET['id'] : 0;

$stmt = $pdo->prepare("
    SELECT i.*, c.company_name, c.industry, c.website
    FROM internships i
    JOIN companies c ON c.id = i.company_id
    WHERE i.id = ?
");
$stmt->execute([$internship_id]);
$internship = $stmt->fetch();

if (!$internship) {
    set_flash('error', 'That internship could not be found.');
    redirect('student/internships.php');
}

$already_applied = null;
if ($student) {
    $stmt = $pdo->prepare("SELECT status FROM applications WHERE student_id = ? AND internship_id = ?");
    $stmt->execute([$student['id'], $internship_id]);
    $row = $stmt->fetch();
    if ($row) $already_applied = $row['status'];
}

$skills = $internship['skills_required']
    ? array_filter(array_map('trim', explode(',', $internship['skills_required'])))
    : [];

$page_title = $internship['title'];
require __DIR__ . '/../includes/header.php';
?>

<div class="ic-container ic-section ic-narrow-page">
  <a href="internships.php" class="ic-btn ic-btn-ghost ic-btn-sm" style="margin-bottom:18px">&larr; Back to listings</a>

  <div class="ic-panel">
    <div class="ic-detail-header">
      <div>
        <h1 style="font-size:1.6rem;margin-bottom:4px"><?= clean($internship['title']) ?></h1>
        <div style="color:var(--text-muted);font-weight:600"><?= clean($internship['company_name']) ?><?= $internship['industry'] ? ' · ' . clean($internship['industry']) : '' ?></div>
      </div>
      <span class="ic-badge badge-<?= $internship['status'] ?>"><?= clean($internship['status']) ?></span>
    </div>

    <div class="ic-detail-meta-grid">
      <div class="ic-detail-meta-item"><span>Location</span><?= clean($internship['location'] ?: 'Not specified') ?></div>
      <div class="ic-detail-meta-item"><span>Work mode</span><?= clean($internship['work_mode']) ?></div>
      <div class="ic-detail-meta-item"><span>Stipend</span><?= clean($internship['stipend'] ?: 'Not specified') ?></div>
      <div class="ic-detail-meta-item"><span>Duration</span><?= clean($internship['duration'] ?: 'Not specified') ?></div>
      <?php if ($internship['deadline']): ?>
        <div class="ic-detail-meta-item"><span>Apply by</span><?= date('d M Y', strtotime($internship['deadline'])) ?></div>
      <?php endif; ?>
      <div class="ic-detail-meta-item"><span>Posted</span><?= date('d M Y', strtotime($internship['posted_at'])) ?></div>
    </div>

    <?php if ($skills): ?>
      <h3 style="font-size:1rem;margin-top:24px">Skills</h3>
      <div class="ic-skills">
        <?php foreach ($skills as $s): ?><span class="ic-skill-chip"><?= clean($s) ?></span><?php endforeach; ?>
      </div>
    <?php endif; ?>

    <h3 style="font-size:1rem;margin-top:24px">About this role</h3>
    <p style="white-space:pre-line;max-width:none"><?= clean($internship['description']) ?></p>

    <?php if ($internship['website'] && preg_match('#^https?://#i', $internship['website'])): ?>
      <p style="font-size:.85rem">Company site: <a href="<?= clean($internship['website']) ?>" target="_blank" rel="noopener"><?= clean($internship['website']) ?></a></p>
    <?php endif; ?>

    <div style="margin-top:28px;padding-top:20px;border-top:1px solid var(--line)">
      <?php if ($already_applied): ?>
        <span class="ic-badge badge-<?= str_replace(' ', '-', $already_applied) ?>">You applied — <?= clean($already_applied) ?></span>
      <?php elseif ($internship['status'] !== 'Open'): ?>
        <span class="ic-badge badge-Closed">This internship is no longer accepting applications</span>
      <?php else: ?>
        <form method="POST" action="apply.php">
          <input type="hidden" name="csrf_token" value="<?= clean(csrf_token()) ?>">
          <input type="hidden" name="internship_id" value="<?= (int) $internship['id'] ?>">
          <input type="hidden" name="return" value="details">
          <button type="submit" class="ic-btn ic-btn-primary" data-loading-text="Applying…">Apply for this internship</button>
        </form>
      <?php endif; ?>
    </div>
  </div>
</div>

<?php require __DIR__ . '/../includes/footer.php'; ?>
