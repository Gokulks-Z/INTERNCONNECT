<?php
require_once __DIR__ . '/../includes/auth.php';
require_role('student');

$pdo = getDBConnection();
$student = get_student_profile($pdo, current_user_id());

$q        = trim((string) ($_GET['q'] ?? ''));
$location = trim((string) ($_GET['location'] ?? ''));
$mode     = trim((string) ($_GET['mode'] ?? ''));

$sql = "SELECT i.*, c.company_name FROM internships i JOIN companies c ON c.id = i.company_id WHERE i.status = 'Open'";
$params = [];

if ($q !== '') {
    $sql .= " AND (i.title LIKE ? OR i.skills_required LIKE ? OR c.company_name LIKE ?)";
    $like = "%$q%";
    array_push($params, $like, $like, $like);
}
if ($location !== '') {
    $sql .= " AND i.location LIKE ?";
    $params[] = "%$location%";
}
if ($mode !== '' && in_array($mode, ['Remote', 'Onsite', 'Hybrid'], true)) {
    $sql .= " AND i.work_mode = ?";
    $params[] = $mode;
}
$sql .= " ORDER BY i.posted_at DESC";

$stmt = $pdo->prepare($sql);
$stmt->execute($params);
$internships = $stmt->fetchAll();

// which internship ids has this student already applied to?
$applied = [];
if ($student) {
    $stmt2 = $pdo->prepare("SELECT internship_id, status FROM applications WHERE student_id = ?");
    $stmt2->execute([$student['id']]);
    foreach ($stmt2->fetchAll() as $row) {
        $applied[$row['internship_id']] = $row['status'];
    }
}

$page_title = 'Browse Internships';
require __DIR__ . '/../includes/header.php';
?>

<div class="ic-container ic-section">
  <header class="ic-page-head">
    <div>
      <p class="ic-eyebrow">Internships</p>
      <h1>Find a role that fits.</h1>
    </div>
  </header>

  <form method="GET" action="internships.php" class="ic-filter-bar">
    <input type="text" name="q" value="<?= clean($q) ?>" placeholder="Search title, skill or company">
    <input type="text" name="location" value="<?= clean($location) ?>" placeholder="Location">
    <select name="mode">
      <option value="">Any work mode</option>
      <?php foreach (['Remote', 'Onsite', 'Hybrid'] as $m): ?>
        <option value="<?= $m ?>" <?= $mode === $m ? 'selected' : '' ?>><?= $m ?></option>
      <?php endforeach; ?>
    </select>
    <button type="submit" class="ic-btn ic-btn-primary">Search</button>
  </form>

  <?php if ($internships): ?>
    <div class="ic-listing">
      <?php foreach ($internships as $i): ?>
        <article class="ic-listing-card">
          <div>
            <h3 style="margin-bottom:2px"><a href="internship_details.php?id=<?= (int) $i['id'] ?>" style="color:inherit"><?= clean($i['title']) ?></a></h3>
            <div style="color:var(--text-muted);font-weight:600;font-size:.9rem"><?= clean($i['company_name']) ?></div>
            <p style="margin:10px 0 0;font-size:.92rem"><?= clean(safe_excerpt($i['description'], 200)) ?></p>
            <div class="ic-listing-meta">
              <span><?= clean($i['location'] ?: 'Not specified') ?></span>
              <span><?= clean($i['work_mode']) ?></span>
              <?php if ($i['stipend']): ?><span><?= clean($i['stipend']) ?></span><?php endif; ?>
              <?php if ($i['duration']): ?><span><?= clean($i['duration']) ?></span><?php endif; ?>
              <?php if ($i['deadline']): ?><span>Apply by <?= date('d M Y', strtotime($i['deadline'])) ?></span><?php endif; ?>
            </div>
            <?php if ($i['skills_required']): ?>
              <div class="ic-skills">
                <?php foreach (array_slice(array_map('trim', explode(',', $i['skills_required'])), 0, 6) as $s): ?>
                  <?php if ($s !== ''): ?><span class="ic-skill-chip"><?= clean($s) ?></span><?php endif; ?>
                <?php endforeach; ?>
              </div>
            <?php endif; ?>
          </div>
          <div class="ic-listing-actions">
            <a href="internship_details.php?id=<?= (int) $i['id'] ?>" class="ic-btn ic-btn-ghost ic-btn-sm">View Details</a>
            <?php if (isset($applied[$i['id']])): ?>
              <span class="ic-badge badge-<?= str_replace(' ', '-', $applied[$i['id']]) ?>"><?= clean($applied[$i['id']]) ?></span>
            <?php else: ?>
              <form method="POST" action="apply.php">
                <input type="hidden" name="csrf_token" value="<?= clean(csrf_token()) ?>">
                <input type="hidden" name="internship_id" value="<?= (int) $i['id'] ?>">
                <button type="submit" class="ic-btn ic-btn-primary ic-btn-sm" data-loading-text="Applying…">Apply</button>
              </form>
            <?php endif; ?>
          </div>
        </article>
      <?php endforeach; ?>
    </div>
  <?php else: ?>
    <div class="ic-empty ic-panel"><h3>No internships found</h3><p>Nothing matches that search right now. Try widening your filters.</p></div>
  <?php endif; ?>
</div>

<?php require __DIR__ . '/../includes/footer.php'; ?>
