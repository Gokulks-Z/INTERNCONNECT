<?php
require_once __DIR__ . '/../includes/auth.php';
require_role('student');

const RESUME_MAX_BYTES = 2097152;

$pdo = getDBConnection();
$userId = current_user_id();
$student = get_student_profile($pdo, $userId);
$errors = [];

/** Confirms the uploaded file's leading bytes match its claimed type. */
function resume_content_matches(string $tmpPath, string $extension): bool
{
    $handle = @fopen($tmpPath, 'rb');
    if ($handle === false) {
        return false;
    }
    $head = (string) fread($handle, 8);
    fclose($handle);

    switch ($extension) {
        case 'pdf':
            return strncmp($head, '%PDF-', 5) === 0;
        case 'docx':
            return strncmp($head, "PK\x03\x04", 4) === 0;
        case 'doc':
            return strncmp($head, "\xD0\xCF\x11\xE0", 4) === 0;
    }
    return false;
}

function remove_stored_resume(?string $filename): void
{
    $name = basename((string) $filename);
    if ($name === '' || !preg_match('/^[A-Za-z0-9_.-]+$/', $name)) {
        return;
    }
    foreach ([storage_path('resumes') . '/' . $name, project_root() . '/uploads/resumes/' . $name] as $path) {
        if (is_file($path)) {
            @unlink($path);
        }
    }
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!csrf_verify($_POST['csrf_token'] ?? '')) {
        $errors[] = 'Your session expired. Please try again.';
    }

    $college    = trim((string) ($_POST['college'] ?? ''));
    $department = trim((string) ($_POST['department'] ?? ''));
    $year       = trim((string) ($_POST['year_of_study'] ?? ''));
    $bio        = trim((string) ($_POST['bio'] ?? ''));
    $resumeHeadline = trim((string) ($_POST['resume_headline'] ?? ''));
    $projectTitle = trim((string) ($_POST['project_title'] ?? ''));
    $projectDescription = trim((string) ($_POST['project_description'] ?? ''));
    $projectUrl = trim((string) ($_POST['project_url'] ?? ''));
    $projectTechStack = trim((string) ($_POST['project_tech_stack'] ?? ''));
    $skills     = implode(', ', parse_skills((string) ($_POST['skills'] ?? '')));
    $resumePath = $student['resume_path'] ?? null;
    $newResume  = null;

    foreach ([['College', $college, 150], ['Department', $department, 100], ['Year of study', $year, 20], ['Bio', $bio, 1000], ['Resume headline', $resumeHeadline, 180], ['Project title', $projectTitle, 180], ['Project description', $projectDescription, 2000], ['Project URL', $projectUrl, 500], ['Project tech stack', $projectTechStack, 255]] as [$label, $value, $max]) {
        if (safe_strlen($value) > $max) {
            $errors[] = $label . ' must be ' . $max . ' characters or fewer.';
        }
    }

    $upload = $_FILES['resume'] ?? null;
    if ($upload && ($upload['error'] ?? UPLOAD_ERR_NO_FILE) !== UPLOAD_ERR_NO_FILE) {
        $extension = strtolower(pathinfo((string) $upload['name'], PATHINFO_EXTENSION));

        if ($upload['error'] === UPLOAD_ERR_INI_SIZE || $upload['error'] === UPLOAD_ERR_FORM_SIZE || $upload['size'] > RESUME_MAX_BYTES) {
            $errors[] = 'Resume must be 2 MB or smaller.';
        } elseif ($upload['error'] !== UPLOAD_ERR_OK || !is_uploaded_file($upload['tmp_name'])) {
            $errors[] = 'The resume could not be uploaded. Please try again.';
        } elseif (!in_array($extension, ['pdf', 'doc', 'docx'], true)) {
            $errors[] = 'Resume must be a PDF, DOC or DOCX file.';
        } elseif (!resume_content_matches($upload['tmp_name'], $extension)) {
            $errors[] = 'That file does not look like a valid ' . strtoupper($extension) . ' document.';
        } else {
            $filename = bin2hex(random_bytes(16)) . '.' . $extension;
            if (@move_uploaded_file($upload['tmp_name'], storage_path('resumes') . '/' . $filename)) {
                $newResume = $filename;
            } else {
                $errors[] = 'The resume could not be saved. Please try again.';
            }
        }
    }

    if ($projectUrl !== '' && !filter_var($projectUrl, FILTER_VALIDATE_URL)) { $errors[] = 'Project URL must be a valid URL.'; }

    if (!$errors) {
        $previousResume = $resumePath;
        if ($newResume !== null) {
            $resumePath = $newResume;
        }

        if ($student) {
            $pdo->prepare('UPDATE students SET college = ?, department = ?, year_of_study = ?, skills = ?, bio = ?, resume_path = ?, resume_headline = ?, project_title = ?, project_description = ?, project_url = ?, project_tech_stack = ? WHERE user_id = ?')
                ->execute([$college, $department, $year, $skills, $bio, $resumePath, $resumeHeadline, $projectTitle, $projectDescription, $projectUrl ?: null, $projectTechStack, $userId]);
        } else {
            $pdo->prepare('INSERT INTO students (user_id, college, department, year_of_study, skills, bio, resume_path, resume_headline, project_title, project_description, project_url, project_tech_stack) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)')
                ->execute([$userId, $college, $department, $year, $skills, $bio, $resumePath, $resumeHeadline, $projectTitle, $projectDescription, $projectUrl ?: null, $projectTechStack]);
        }

        if ($newResume !== null && $previousResume) {
            remove_stored_resume($previousResume);
        }

        set_flash('success', 'Profile saved.');
        redirect('student/profile.php');
    }

    if ($newResume !== null) {
        remove_stored_resume($newResume);
    }
    $student = array_merge($student ?: [], [
        'college' => $college, 'department' => $department, 'year_of_study' => $year,
        'skills' => $skills, 'bio' => $bio, 'resume_path' => $student['resume_path'] ?? null,
        'resume_headline' => $resumeHeadline, 'project_title' => $projectTitle, 'project_description' => $projectDescription, 'project_url' => $projectUrl, 'project_tech_stack' => $projectTechStack,
        'id' => $student['id'] ?? null,
    ]);
}

$completion = student_completion($student);
$skillList = parse_skills((string) ($student['skills'] ?? ''));

$page_title = 'Profile';
require __DIR__ . '/../includes/header.php';
?>

<div class="ic-container ic-section">
  <header class="ic-page-head">
    <div>
      <p class="ic-eyebrow">Your profile</p>
      <h1>What companies see when you apply.</h1>
    </div>
    <div class="ic-completion" aria-label="Profile completion">
      <div class="ic-completion-top"><strong><?= (int) $completion['percent'] ?>%</strong><span>complete</span></div>
      <div class="ic-meter"><span style="width:<?= (int) $completion['percent'] ?>%"></span></div>
      <?php if ($completion['missing']): ?>
        <small>Still missing: <?= clean(implode(', ', $completion['missing'])) ?></small>
      <?php else: ?>
        <small>Everything is filled in.</small>
      <?php endif; ?>
    </div>
  </header>

  <?php if ($errors): ?>
    <div class="ic-flash ic-flash-error" role="alert">
      <?php foreach ($errors as $error): ?><div><?= clean($error) ?></div><?php endforeach; ?>
    </div>
  <?php endif; ?>

  <form method="POST" action="profile.php" enctype="multipart/form-data" class="ic-form-grid" novalidate>
    <?= csrf_field() ?>
    <input type="hidden" name="MAX_FILE_SIZE" value="<?= RESUME_MAX_BYTES ?>">

    <section class="ic-panel">
      <h2>Education</h2>
      <div class="ic-field">
        <label for="college">College</label>
        <input type="text" id="college" name="college" value="<?= clean($student['college'] ?? '') ?>" maxlength="150">
      </div>
      <div class="ic-field-pair">
        <div class="ic-field">
          <label for="department">Department</label>
          <input type="text" id="department" name="department" value="<?= clean($student['department'] ?? '') ?>" maxlength="100">
        </div>
        <div class="ic-field">
          <label for="year_of_study">Year of study</label>
          <input type="text" id="year_of_study" name="year_of_study" value="<?= clean($student['year_of_study'] ?? '') ?>" maxlength="20">
        </div>
      </div>
      <div class="ic-field">
        <label for="bio">Short bio</label>
        <textarea id="bio" name="bio" maxlength="1000" placeholder="A few sentences about what you are looking for."><?= clean($student['bio'] ?? '') ?></textarea>
      </div>
    </section>

    <section class="ic-panel">
      <h2>Skills and resume</h2>
      <div class="ic-field">
        <label for="skills">Skills</label>
        <input type="text" id="skills" name="skills" value="<?= clean($student['skills'] ?? '') ?>" placeholder="PHP, MySQL, JavaScript">
        <div class="ic-hint">Separate skills with commas. Up to 20.</div>
        <?php if ($skillList): ?>
          <div class="ic-skills">
            <?php foreach ($skillList as $skill): ?><span class="ic-skill-chip"><?= clean($skill) ?></span><?php endforeach; ?>
          </div>
        <?php endif; ?>
      </div>

      <div class="ic-field">
        <label for="resume_headline">Resume headline</label>
        <input type="text" id="resume_headline" name="resume_headline" maxlength="180" value="<?= clean($student['resume_headline'] ?? '') ?>" placeholder="e.g. Computer Science student | Full-stack developer">
        <div class="ic-hint">A concise introduction shown with your resume.</div>
      </div>
      <div class="ic-field" id="field-resume">
        <label for="resume">Resume</label>
        <input type="file" id="resume" name="resume" accept=".pdf,.doc,.docx">
        <div class="ic-hint">PDF, DOC or DOCX, up to 2 MB.</div>
        <div class="ic-error-text"></div>
        <?php if (!empty($student['resume_path']) && !empty($student['id'])): ?>
          <p class="ic-file-current">Current file: <a href="<?= clean(url('resume.php?student=' . (int) $student['id'])) ?>" target="_blank" rel="noopener">view resume</a></p>
        <?php endif; ?>
      </div>

      <div class="ic-profile-project">
        <p class="ic-eyebrow">Show what you build</p>
        <h2>Featured project</h2>
        <div class="ic-field">
          <label for="project_title">Project title</label>
          <input type="text" id="project_title" name="project_title" maxlength="180" value="<?= clean($student['project_title'] ?? '') ?>" placeholder="e.g. Smart Campus Portal">
        </div>
        <div class="ic-field">
          <label for="project_description">Project description</label>
          <textarea id="project_description" name="project_description" maxlength="2000" placeholder="What problem does it solve? What did you contribute?"><?= clean($student['project_description'] ?? '') ?></textarea>
        </div>
        <div class="ic-field">
          <label for="project_tech_stack">Technologies used</label>
          <input type="text" id="project_tech_stack" name="project_tech_stack" maxlength="255" value="<?= clean($student['project_tech_stack'] ?? '') ?>" placeholder="PHP, MySQL, JavaScript">
        </div>
        <div class="ic-field">
          <label for="project_url">Project URL</label>
          <input type="url" id="project_url" name="project_url" maxlength="500" value="<?= clean($student['project_url'] ?? '') ?>" placeholder="https://github.com/yourname/project">
        </div>
      </div>
      <button type="submit" class="ic-btn ic-btn-primary" data-loading-text="Saving…">Save profile</button>
    </section>
  </form>
</div>

<?php require __DIR__ . '/../includes/footer.php'; ?>
