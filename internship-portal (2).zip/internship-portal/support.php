<?php
require_once __DIR__ . '/includes/auth.php';
require_once __DIR__ . '/includes/schema.php';

const SUPPORT_CATEGORIES = ['Account', 'Login / Password', 'Internship', 'Application', 'Company', 'Technical Issue', 'Other'];

$pdo = getDBConnection();
ensure_aux_tables($pdo);

$userId = current_user_id();
$errors = [];
$old = ['name' => '', 'email' => '', 'category' => '', 'subject' => '', 'message' => '', 'reference' => ''];

if ($userId !== null) {
    $stmt = $pdo->prepare('SELECT full_name, email FROM users WHERE id = ? LIMIT 1');
    $stmt->execute([$userId]);
    $account = $stmt->fetch();
    if ($account) {
        $old['name'] = $account['full_name'];
        $old['email'] = $account['email'];
    }
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!csrf_verify($_POST['csrf_token'] ?? '')) {
        $errors[] = 'Your session expired. Please try again.';
    }

    foreach (['name', 'email', 'category', 'subject', 'message', 'reference'] as $field) {
        $old[$field] = trim((string) ($_POST[$field] ?? $old[$field]));
    }
    // A logged-in user's identity comes from their account, not from the form.
    if ($userId !== null && isset($account) && $account) {
        $old['name'] = $account['full_name'];
        $old['email'] = $account['email'];
    }
    $old['email'] = strtolower($old['email']);

    if (safe_strlen($old['name']) < 2 || safe_strlen($old['name']) > 100) {
        $errors[] = 'Enter your name (2 to 100 characters).';
    }
    if (!filter_var($old['email'], FILTER_VALIDATE_EMAIL) || safe_strlen($old['email']) > 150) {
        $errors[] = 'Enter a valid email address.';
    }
    if (!in_array($old['category'], SUPPORT_CATEGORIES, true)) {
        $errors[] = 'Choose a category.';
    }
    $subjectLength = safe_strlen($old['subject']);
    if ($subjectLength < 4 || $subjectLength > 150) {
        $errors[] = 'Give your request a subject (4 to 150 characters).';
    }
    $messageLength = safe_strlen($old['message']);
    if ($messageLength < 20) {
        $errors[] = 'Describe the issue in at least 20 characters so we can help.';
    } elseif ($messageLength > 3000) {
        $errors[] = 'Please keep the message under 3000 characters.';
    }
    if (safe_strlen($old['reference']) > 100) {
        $errors[] = 'The reference must be 100 characters or fewer.';
    }

    if (!$errors && !throttle_allowed('support-submit', 5, 3600)) {
        $errors[] = 'You have sent several requests recently. Please wait a while before sending another.';
    }

    if (!$errors) {
        $recent = $pdo->prepare(
            'SELECT COUNT(*) FROM support_queries
             WHERE email = ? AND created_at > (NOW() - INTERVAL 1 HOUR)'
        );
        $recent->execute([$old['email']]);
        if ((int) $recent->fetchColumn() >= 5) {
            $errors[] = 'There are already several open requests from this email. We will get back to you soon.';
        }
    }

    if (!$errors) {
        throttle_hit('support-submit');
        try {
            $pdo->prepare(
                'INSERT INTO support_queries (user_id, name, email, category, subject, message, reference)
                 VALUES (?, ?, ?, ?, ?, ?, ?)'
            )->execute([
                $userId,
                $old['name'],
                $old['email'],
                $old['category'],
                $old['subject'],
                $old['message'],
                $old['reference'] !== '' ? $old['reference'] : null,
            ]);
            set_flash('success', 'Request received. We will reply to ' . $old['email'] . '.');
            redirect('support.php?sent=1');
        } catch (PDOException $e) {
            error_log('InternConnect: support request failed (code ' . $e->getCode() . ').');
            $errors[] = 'We could not save your request right now. Please try again.';
        }
    }
}

$myQueries = [];
if ($userId !== null) {
    $stmt = $pdo->prepare(
        'SELECT subject, category, status, created_at FROM support_queries
         WHERE user_id = ? ORDER BY created_at DESC LIMIT 6'
    );
    $stmt->execute([$userId]);
    $myQueries = $stmt->fetchAll();
}

$sent = isset($_GET['sent']);
$page_title = 'Queries & Support';
require __DIR__ . '/includes/header.php';
?>

<div class="ic-container ic-section">
  <div class="ic-support-grid">
    <div class="ic-support-intro">
      <p class="ic-eyebrow">Queries &amp; Support</p>
      <h1>Tell us what is not working.</h1>
      <p>Report a problem, ask a question, or raise a concern about an internship or application. Every request is stored and tracked until it is resolved.</p>

      <ul class="ic-support-notes">
        <li><strong>Be specific.</strong> Mention the internship title or what you clicked before the problem.</li>
        <li><strong>Passwords.</strong> We will never ask for your password in a request.</li>
        <li><strong>Status.</strong> Requests move through Open, In Progress, Resolved and Closed.</li>
      </ul>

      <?php if ($myQueries): ?>
        <div class="ic-panel ic-support-history">
          <h2>Your recent requests</h2>
          <ul>
            <?php foreach ($myQueries as $query): ?>
              <li>
                <div>
                  <strong><?= clean($query['subject']) ?></strong>
                  <span><?= clean($query['category']) ?> · <?= clean(date('d M Y', strtotime($query['created_at']))) ?></span>
                </div>
                <span class="ic-badge badge-support-<?= clean(str_replace(' ', '-', $query['status'])) ?>"><?= clean($query['status']) ?></span>
              </li>
            <?php endforeach; ?>
          </ul>
        </div>
      <?php endif; ?>
    </div>

    <div class="ic-panel ic-support-form">
      <?php if ($sent): ?>
        <div class="ic-success-state">
          <span class="ic-success-check" aria-hidden="true">&#10003;</span>
          <h2>Request received</h2>
          <p>Thanks. Your request is now Open and we will reply by email.</p>
          <a href="support.php" class="ic-btn ic-btn-ghost">Send another request</a>
        </div>
      <?php else: ?>
        <h2>New request</h2>

        <?php if ($errors): ?>
          <div class="ic-flash ic-flash-error" role="alert">
            <?php foreach ($errors as $error): ?><div><?= clean($error) ?></div><?php endforeach; ?>
          </div>
        <?php endif; ?>

        <form method="POST" action="support.php" novalidate>
          <?= csrf_field() ?>

          <div class="ic-field-pair">
            <div class="ic-field">
              <label for="name">Name</label>
              <input type="text" id="name" name="name" value="<?= clean($old['name']) ?>" maxlength="100" required <?= $userId !== null ? 'readonly' : '' ?> autocomplete="name">
            </div>
            <div class="ic-field">
              <label for="email">Email</label>
              <input type="email" id="email" name="email" value="<?= clean($old['email']) ?>" maxlength="150" required <?= $userId !== null ? 'readonly' : '' ?> autocomplete="email">
            </div>
          </div>

          <div class="ic-field-pair">
            <div class="ic-field">
              <label for="category">Category</label>
              <select id="category" name="category" required>
                <option value="">Choose one</option>
                <?php foreach (SUPPORT_CATEGORIES as $category): ?>
                  <option value="<?= clean($category) ?>" <?= $old['category'] === $category ? 'selected' : '' ?>><?= clean($category) ?></option>
                <?php endforeach; ?>
              </select>
            </div>
            <div class="ic-field">
              <label for="reference">Internship or application <span class="ic-optional">(optional)</span></label>
              <input type="text" id="reference" name="reference" value="<?= clean($old['reference']) ?>" maxlength="100" placeholder="e.g. Backend Intern">
            </div>
          </div>

          <div class="ic-field">
            <label for="subject">Subject</label>
            <input type="text" id="subject" name="subject" value="<?= clean($old['subject']) ?>" maxlength="150" required>
          </div>

          <div class="ic-field">
            <label for="message">Message</label>
            <textarea id="message" name="message" rows="6" maxlength="3000" required><?= clean($old['message']) ?></textarea>
            <div class="ic-hint">At least 20 characters.</div>
          </div>

          <button type="submit" class="ic-btn ic-btn-primary" data-loading-text="Sending…">Send request</button>
        </form>
      <?php endif; ?>
    </div>
  </div>
</div>

<?php require __DIR__ . '/includes/footer.php'; ?>
